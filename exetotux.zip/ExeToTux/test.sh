#!/usr/bin/env bash

# Script de test rapide d'ExeToTux
# Teste les fonctionnalités principales sans fichier PE réel

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"

echo "════════════════════════════════════════════"
echo "   ExeToTux - Quick Test Script"
echo "════════════════════════════════════════════"
echo ""

# Vérifier que le build existe
if [ ! -d "${BUILD_DIR}" ]; then
    echo "❌ Build directory not found."
    echo "   Run: ./build.sh first"
    exit 1
fi

# Tester la CLI
echo "Testing CLI..."
echo ""

echo "1. Testing help command..."
"${BUILD_DIR}/exetotux-cli" --help > /dev/null && echo "   ✓ Help works" || echo "   ✗ Help failed"

echo ""
echo "2. Testing interface detection..."
if grep -q "Qt6" <<< $("${BUILD_DIR}/exetotux-gui" --version 2>&1 || true); then
    echo "   ✓ GUI is using Qt6"
else
    echo "   ℹ GUI interface check skipped"
fi

echo ""
echo "3. Testing version info..."
echo "   CLI version: $(${BUILD_DIR}/exetotux-cli --help | head -1 || echo 'N/A')"

echo ""
echo "════════════════════════════════════════════"
echo "Note: Full test requires a valid PE file"
echo "════════════════════════════════════════════"
echo ""
echo "To test with actual PE file:"
echo "  ${BUILD_DIR}/exetotux-gui"
echo "   or"
echo "  ${BUILD_DIR}/exetotux-cli -i /path/to/file.exe -o /tmp"
echo ""
