#include "conversion_controller.h"
#include "logger.h"
#include <sstream>
#include <cstdio>

ConversionController::ConversionController() {}

ConversionController::~ConversionController() {}

bool ConversionController::convert(const std::string& exePath,
                                   const std::string& outputDir,
                                   PackageFormat format,
                                   ProgressCallback progressCallback) {
    LOG_INFO("Démarrage de la conversion du fichier: " + exePath);
    
    reportProgress(5, "Analyse du fichier PE...", progressCallback);
    
    // Analyser le fichier PE
    lastMetadata = peAnalyzer.analyzeFile(exePath);
    
    if (!lastMetadata.isValid) {
        lastError = "Fichier PE invalide: " + lastMetadata.errorMessage;
        LOG_ERROR(lastError);
        reportProgress(0, lastError, progressCallback);
        return false;
    }
    
    reportProgress(25, "PE analysé - Génération du wrapper...", progressCallback);
    
    // Générer le paquet
    std::string outputPackagePath = outputDir + "/" + lastMetadata.appName + 
                                   (format == PackageFormat::DEB ? ".deb" : ".rpm");
    
    reportProgress(50, "Construction du paquet...", progressCallback);
    
    if (!packageGenerator.generatePackage(exePath, lastMetadata, format, outputPackagePath)) {
        lastError = packageGenerator.getLastError();
        LOG_ERROR(lastError);
        reportProgress(0, lastError, progressCallback);
        return false;
    }
    
    reportProgress(100, "Conversion réussie!", progressCallback);
    LOG_INFO("Conversion terminée avec succès: " + outputPackagePath);
    
    return true;
}

std::string ConversionController::generateComparisonReport(const std::string& peFilePath,
                                                            const std::string& elfFilePath) {
    LOG_INFO("Génération du rapport de comparaison PE vs ELF");
    
    std::stringstream report;
    
    report << "═══════════════════════════════════════════════════════════\n";
    report << "           RAPPORT DE COMPARAISON PE vs ELF\n";
    report << "═══════════════════════════════════════════════════════════\n\n";
    
    // Analyser le PE
    PEMetadata peData = peAnalyzer.analyzeFile(peFilePath);
    
    report << "📊 FORMAT PE (Portable Executable)\n";
    report << "─────────────────────────────────────────────────────────────\n";
    report << "Fichier: " << peFilePath << "\n";
    report << "Valide: " << (peData.isValid ? "OUI" : "NON") << "\n";
    report << "Taille: " << peData.fileSize << " bytes\n";
    report << "Architecture: " << peData.architecture << "\n";
    report << "Machine Type: 0x" << std::hex << peData.machineType << std::dec << "\n";
    report << "Subsystem: " << PEAnalyzer::getSubsystemDescription(peData.subsystem) 
           << " (" << std::dec << peData.subsystem << ")\n";
    report << "Sections: " << peData.sections.size() << "\n";
    for (const auto& section : peData.sections) {
        report << "  - " << section << "\n";
    }
    report << "\n";
    
    report << "📦 FORMAT ELF (Executable and Linkable Format)\n";
    report << "─────────────────────────────────────────────────────────────\n";
    report << "Fichier: " << elfFilePath << "\n";
    report << "Type: Linux native executable wrapper\n";
    report << "Contenu: Wrapper C compilé + ressource PE embarquée\n";
    report << "Plateforme: Linux (Debian/Ubuntu, Fedora, etc.)\n";
    
    FILE* elfFile = fopen(elfFilePath.c_str(), "rb");
    if (elfFile) {
        fseek(elfFile, 0, SEEK_END);
        size_t fsize = ftell(elfFile);
        fclose(elfFile);
        report << "Taille: " << fsize << " bytes\n";
    }
    report << "\n";
    
    report << "🔍 ANALYSE COMPARÉE\n";
    report << "─────────────────────────────────────────────────────────────\n";
    report << "✓ PE Valide: " << (peData.isValid ? "OUI" : "NON") << "\n";
    report << "✓ Architecture détectée: " << peData.architecture << "\n";
    report << "✓ Application: " << peData.appName << "\n";
    report << "✓ Type subsystem: " << PEAnalyzer::getSubsystemDescription(peData.subsystem) << "\n";
    report << "✓ Wrapper ELF généré: " << elfFilePath << "\n";
    report << "✓ Status exécution: Non-fonctionnel (Intentionnel)\n";
    report << "\n";
    
    report << "⚠️  NOTES IMPORTANTES:\n";
    report << "─────────────────────────────────────────────────────────────\n";
    report << "• Le wrapper ELF ne peut pas exécuter le code binaire PE\n";
    report << "• Cet outil est expérimental et pédagogique\n";
    report << "• Pour exécuter l'application, utilisez Wine, Proton, ou VM\n";
    report << "• Le fichier .exe original est préservé dans le paquet\n";
    
    return report.str();
}

void ConversionController::reportProgress(int percent, 
                                         const std::string& message,
                                         ProgressCallback& callback) {
    if (callback) {
        callback(percent, message);
    }
    LOG_INFO("Progression: " + std::to_string(percent) + "% - " + message);
}
