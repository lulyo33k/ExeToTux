#include <QApplication>
#include "mainwindow.h"
#include "logger.h"

int main(int argc, char *argv[]) {
    QApplication app(argc, argv);
    
    // Initialiser le logger
    Logger::getInstance().init("/tmp/exetotux.log", true);
    LOG_INFO("=== ExeToTux GUI Application Started ===");
    
    MainWindow window;
    window.show();
    
    return app.exec();
}
