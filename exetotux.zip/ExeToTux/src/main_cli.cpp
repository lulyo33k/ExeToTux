#include "conversion_controller.h"
#include "logger.h"
#include <iostream>
#include <cstring>
#include <filesystem>

namespace fs = std::filesystem;

void printUsage(const char* programName) {
    std::cout << "\n";
    std::cout << "╔════════════════════════════════════════════╗\n";
    std::cout << "║     ExeToTux - PE to Linux Converter       ║\n";
    std::cout << "║         Mode Ligne de Commande             ║\n";
    std::cout << "╚════════════════════════════════════════════╝\n\n";
    
    std::cout << "Usage: " << programName << " [OPTIONS]\n\n";
    
    std::cout << "OPTIONS:\n";
    std::cout << "  -h, --help              Afficher cette aide\n";
    std::cout << "  -i, --input FILE        Chemin vers le fichier .exe (REQUIS)\n";
    std::cout << "  -o, --output DIR        Répertoire de sortie (par défaut: ./)\n";
    std::cout << "  -f, --format FORMAT     Format de paquet: deb ou rpm (par défaut: deb)\n";
    std::cout << "  -a, --analyze           Analyser uniquement le fichier PE\n";
    std::cout << "  -l, --log FILE          Chemin du fichier de log\n";
    std::cout << "  -v, --verbose           Mode verbose\n\n";
    
    std::cout << "EXEMPLES:\n";
    std::cout << "  " << programName << " -i app.exe -o /tmp -f deb\n";
    std::cout << "  " << programName << " -a -i app.exe\n";
    std::cout << "  " << programName << " -i app.exe -o ./ -f rpm -v\n\n";
}

void printAnalysisResult(const PEMetadata& metadata) {
    std::cout << "\n";
    std::cout << "═══════════════════════════════════════════════════════════\n";
    std::cout << "                 ANALYSE DU FICHIER PE\n";
    std::cout << "═══════════════════════════════════════════════════════════\n\n";
    
    if (!metadata.isValid) {
        std::cout << "❌ ERREUR: Fichier PE invalide\n";
        std::cout << "Détail: " << metadata.errorMessage << "\n";
        return;
    }
    
    std::cout << "✓ VALIDE\n\n";
    std::cout << "📋 MÉTADONNÉES:\n";
    std::cout << "  Nom: " << metadata.appName << "\n";
    std::cout << "  Fichier: " << metadata.filename << "\n";
    std::cout << "  Taille: " << metadata.fileSize << " bytes (" 
              << (metadata.fileSize / 1024.0 / 1024.0) << " MB)\n\n";
    
    std::cout << "🏗️  ARCHITECTURE:\n";
    std::cout << "  Type machine: " << PEAnalyzer::getMachineTypeDescription(metadata.machineType) << "\n";
    std::cout << "  Machine code: 0x" << std::hex << metadata.machineType << std::dec << "\n";
    std::cout << "  Subsystem: " << PEAnalyzer::getSubsystemDescription(metadata.subsystem) << "\n\n";
    
    std::cout << "📦 SECTIONS (" << metadata.sections.size() << "):\n";
    for (const auto& section : metadata.sections) {
        std::cout << "  • " << section << "\n";
    }
    
    std::cout << "\n";
}

int main(int argc, char *argv[]) {
    std::string inputFile, outputDir = "./", logFile = "/tmp/exetotux_cli.log";
    std::string formatStr = "deb";
    bool analyzeOnly = false;
    bool verbose = false;
    
    // Parser les arguments
    if (argc < 2) {
        printUsage(argv[0]);
        return 1;
    }
    
    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        
        if (arg == "-h" || arg == "--help") {
            printUsage(argv[0]);
            return 0;
        } else if (arg == "-i" || arg == "--input") {
            if (i + 1 < argc) {
                inputFile = argv[++i];
            } else {
                std::cerr << "Erreur: -i/--input requiert une valeur\n";
                return 1;
            }
        } else if (arg == "-o" || arg == "--output") {
            if (i + 1 < argc) {
                outputDir = argv[++i];
            } else {
                std::cerr << "Erreur: -o/--output requiert une valeur\n";
                return 1;
            }
        } else if (arg == "-f" || arg == "--format") {
            if (i + 1 < argc) {
                formatStr = argv[++i];
            } else {
                std::cerr << "Erreur: -f/--format requiert une valeur\n";
                return 1;
            }
        } else if (arg == "-a" || arg == "--analyze") {
            analyzeOnly = true;
        } else if (arg == "-l" || arg == "--log") {
            if (i + 1 < argc) {
                logFile = argv[++i];
            } else {
                std::cerr << "Erreur: -l/--log requiert une valeur\n";
                return 1;
            }
        } else if (arg == "-v" || arg == "--verbose") {
            verbose = true;
        } else {
            std::cerr << "Erreur: Argument inconnu: " << arg << "\n";
            return 1;
        }
    }
    
    // Initialiser le logger
    Logger::getInstance().init(logFile, verbose);
    LOG_INFO("=== ExeToTux CLI Started ===");
    
    // Valider les entrées
    if (inputFile.empty()) {
        std::cerr << "Erreur: Le fichier d'entrée -i/--input est requis\n";
        return 1;
    }
    
    if (!fs::exists(inputFile)) {
        std::cerr << "Erreur: Le fichier n'existe pas: " << inputFile << "\n";
        return 1;
    }
    
    if (!fs::is_regular_file(inputFile)) {
        std::cerr << "Erreur: Ce n'est pas un fichier régulier\n";
        return 1;
    }
    
    if (!fs::exists(outputDir)) {
        std::cerr << "Erreur: Le répertoire de sortie n'existe pas: " << outputDir << "\n";
        return 1;
    }
    
    // Mode analyse uniquement
    if (analyzeOnly) {
        LOG_INFO("Mode analyse uniquement activé");
        ConversionController controller;
        PEAnalyzer peAnalyzer;
        PEMetadata metadata = peAnalyzer.analyzeFile(inputFile);
        printAnalysisResult(metadata);
        return metadata.isValid ? 0 : 1;
    }
    
    // Valider le format
    PackageFormat format;
    if (formatStr == "deb") {
        format = PackageFormat::DEB;
    } else if (formatStr == "rpm") {
        format = PackageFormat::RPM;
    } else {
        std::cerr << "Erreur: Format invalide: " << formatStr 
                  << " (deb ou rpm)\n";
        return 1;
    }
    
    // Lancer la conversion
    std::cout << "\n";
    std::cout << "═══════════════════════════════════════════════════════════\n";
    std::cout << "           Conversion PE -> Paquet Linux\n";
    std::cout << "═══════════════════════════════════════════════════════════\n\n";
    
    ConversionController controller;
    
    auto progressCallback = [](int percent, const std::string& message) {
        std::cout << "[" << percent << "%] " << message << "\n";
    };
    
    bool success = controller.convert(inputFile, outputDir, format, progressCallback);
    
    if (success) {
        const PEMetadata& metadata = controller.getLastMetadata();
        std::string packagePath = outputDir + "/" + metadata.appName + 
                                 (format == PackageFormat::DEB ? ".deb" : ".rpm");
        
        std::cout << "\n✅ SUCCÈS!\n";
        std::cout << "Paquet créé: " << packagePath << "\n";
        std::cout << "Log: " << logFile << "\n\n";
        
        return 0;
    } else {
        std::cout << "\n❌ ERREUR: " << controller.getLastError() << "\n\n";
        return 1;
    }
}
