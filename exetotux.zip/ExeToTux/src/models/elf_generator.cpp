#include "elf_generator.h"
#include "logger.h"
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <unistd.h>
#include <sys/stat.h>

ELFGenerator::ELFGenerator() {}

ELFGenerator::~ELFGenerator() {}

std::string ELFGenerator::generateWrapperC(const std::string& appName,
                                          const std::string& exePath,
                                          const PEMetadata& metadata) {
    LOG_INFO("Génération du wrapper C pour: " + appName);
    
    std::stringstream ss;
    
    ss << generateCHeader(appName);
    ss << "\n";
    ss << generateCMain(appName, metadata);
    
    return ss.str();
}

std::string ELFGenerator::generateCHeader(const std::string& appName) {
    std::stringstream ss;
    
    ss << "#include <stdio.h>\n";
    ss << "#include <stdlib.h>\n";
    ss << "#include <string.h>\n";
    ss << "#include <unistd.h>\n";
    ss << "\n";
    ss << "/* Wrapper ELF généré automatiquement par ExeToTux */\n";
    ss << "/* Application: " << appName << " */\n";
    ss << "\n";
    ss << "#define APP_NAME \"" << appName << "\"\n";
    ss << "#define VERSION \"1.0\"\n";
    
    return ss.str();
}

std::string ELFGenerator::generateCMain(const std::string& appName,
                                        const PEMetadata& metadata) {
    std::stringstream ss;
    
    ss << "\nint show_info() {\n";
    ss << "    printf(\"\\n\");\n";
    ss << "    printf(\"╔════════════════════════════════════════════╗\\n\");\n";
    ss << "    printf(\"║     ExeToTux - PE to Linux Wrapper        ║\\n\");\n";
    ss << "    printf(\"╚════════════════════════════════════════════╝\\n\\n\");\n";
    ss << "    printf(\"📦 Application détectée: %s\\n\", APP_NAME);\n";
    ss << "    printf(\"🔧 Architecture: " << metadata.architecture << "\\n\");\n";
    ss << "    printf(\"📋 Subsystem: " << PEAnalyzer::getSubsystemDescription(metadata.subsystem) << "\\n\");\n";
    ss << "    printf(\"💾 Taille fichier: %lu bytes\\n\", (unsigned long)" << metadata.fileSize << ");\n";
    ss << "    printf(\"\\n\");\n";
    ss << "    printf(\"⚠️  AVERTISSEMENT: Cette application est une exécutable Windows\\n\");\n";
    ss << "    printf(\"                  Elle ne peut pas être exécutée nativement sur Linux.\\n\");\n";
    ss << "    printf(\"                  Ce wrapper affiche uniquement les métadonnées.\\n\");\n";
    ss << "    printf(\"\\n\");\n";
    ss << "    printf(\"💡 Pour exécuter cette application, utilisez:\\n\");\n";
    ss << "    printf(\"   - Wine: wine /opt/" << appName << "/app.exe\\n\");\n";
    ss << "    printf(\"   - Proton/Lutris: Pour les jeux\\n\");\n";
    ss << "    printf(\"   - VirtualBox: Avec Windows installé\\n\");\n";
    ss << "    printf(\"\\n\");\n";
    ss << "    return 0;\n";
    ss << "}\n";
    ss << "\n";
    ss << "int main(int argc, char* argv[]) {\n";
    ss << "    /* Afficher les informations */\n";
    ss << "    show_info();\n";
    ss << "    \n";
    ss << "    /* Afficher un message final */\n";
    ss << "    if (argc > 1 && strcmp(argv[1], \"--info\") == 0) {\n";
    ss << "        printf(\"Fichier .exe stocké à: /opt/" << appName << "/app.exe\\n\");\n";
    ss << "        printf(\"Chemin du launcher: %s\\n\", argv[0]);\n";
    ss << "    }\n";
    ss << "    \n";
    ss << "    return 1;  /* Exécution non compatible - retour code d'erreur */\n";
    ss << "}\n";
    
    return ss.str();
}

bool ELFGenerator::checkCompiler() {
    int ret = system("which gcc >/dev/null 2>&1");
    if (ret == 0) {
        LOG_DEBUG("gcc trouvé");
        return true;
    }
    
    ret = system("which clang >/dev/null 2>&1");
    if (ret == 0) {
        LOG_DEBUG("clang trouvé");
        return true;
    }
    
    lastError = "Aucun compilateur C trouvé (gcc ou clang requis)";
    LOG_ERROR(lastError);
    return false;
}

bool ELFGenerator::compileCToELF(const std::string& cFilePath,
                                 const std::string& outputPath,
                                 const std::string& optimizationLevel) {
    if (!checkCompiler()) {
        return false;
    }
    
    LOG_INFO("Compilation du wrapper C en ELF");
    
    std::string command = "gcc " + optimizationLevel + " -static-libgcc -s " +
                         cFilePath + " -o " + outputPath + " 2>&1";
    
    int ret = system(command.c_str());
    
    if (ret != 0) {
        lastError = "Erreur lors de la compilation du wrapper";
        LOG_ERROR(lastError);
        return false;
    }
    
    // Rendre l'exécutable
    chmod(outputPath.c_str(), 0755);
    
    LOG_INFO("Wrapper compilé avec succès: " + outputPath);
    return true;
}

bool ELFGenerator::executeCommand(const std::string& command) {
    int ret = system(command.c_str());
    return ret == 0;
}
