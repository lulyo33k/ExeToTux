#include "pe_analyzer.h"
#include "logger.h"
#include <cstring>
#include <cstdio>
#include <algorithm>
#include <sstream>

// Constantes PE
#define DOS_SIGNATURE 0x5A4D          // "MZ"
#define PE_SIGNATURE 0x00004550       // "PE\0\0"
#define MACHINE_I386 0x014c
#define MACHINE_X64 0x8664
#define MACHINE_ARM 0x01c0

PEAnalyzer::PEAnalyzer() {}

PEAnalyzer::~PEAnalyzer() {}

PEMetadata PEAnalyzer::analyzeFile(const std::string& filePath) {
    PEMetadata metadata;
    metadata.filename = filePath;
    metadata.isValid = false;
    metadata.hasIcon = false;
    
    LOG_INFO("Analyse du fichier PE: " + filePath);
    
    FILE* file = fopen(filePath.c_str(), "rb");
    if (!file) {
        metadata.errorMessage = "Impossible d'ouvrir le fichier";
        LOG_ERROR(metadata.errorMessage);
        return metadata;
    }
    
    // Lire la taille du fichier
    fseek(file, 0, SEEK_END);
    metadata.fileSize = ftell(file);
    fseek(file, 0, SEEK_SET);
    
    // Valider le header DOS
    if (!validateDOSHeader(file)) {
        metadata.errorMessage = "En-tête DOS non valide";
        LOG_ERROR(metadata.errorMessage);
        fclose(file);
        return metadata;
    }
    
    // Valider le header PE
    if (!validatePEHeader(file, metadata)) {
        metadata.errorMessage = "En-tête PE non valide";
        LOG_ERROR(metadata.errorMessage);
        fclose(file);
        return metadata;
    }
    
    // Extraire le nom de l'application
    metadata.appName = extractApplicationName(filePath);
    
    // Extraire les sections
    extractSections(file, metadata);
    
    metadata.isValid = true;
    LOG_INFO("Fichier PE analysé avec succès: " + metadata.appName);
    
    fclose(file);
    return metadata;
}

bool PEAnalyzer::validateDOSHeader(FILE* file) {
    uint16_t dosSignature;
    fseek(file, 0, SEEK_SET);
    
    if (fread(&dosSignature, sizeof(uint16_t), 1, file) != 1) {
        return false;
    }
    
    if (dosSignature != DOS_SIGNATURE) {
        LOG_WARNING("Signature DOS invalide: " + std::to_string(dosSignature));
        return false;
    }
    
    return true;
}

bool PEAnalyzer::validatePEHeader(FILE* file, PEMetadata& metadata) {
    // Lire le offset PE depuis le header DOS (offset 0x3C)
    fseek(file, 0x3C, SEEK_SET);
    uint32_t peOffset;
    
    if (fread(&peOffset, sizeof(uint32_t), 1, file) != 1) {
        return false;
    }
    
    // Aller au header PE
    fseek(file, peOffset, SEEK_SET);
    uint32_t peSignature;
    
    if (fread(&peSignature, sizeof(uint32_t), 1, file) != 1) {
        return false;
    }
    
    if (peSignature != PE_SIGNATURE) {
        LOG_WARNING("Signature PE invalide");
        return false;
    }
    
    // Lire le COFF header
    uint16_t machine;
    if (fread(&machine, sizeof(uint16_t), 1, file) != 1) {
        return false;
    }
    
    metadata.machineType = machine;
    metadata.architecture = getMachineTypeDescription(machine);
    
    LOG_INFO("Architecture détectée: " + metadata.architecture);
    
    // Lire le nombre de sections et autres infos
    uint16_t numSections;
    if (fread(&numSections, sizeof(uint16_t), 1, file) != 1) {
        return false;
    }
    
    // Sauter à l'optional header pour le subsystem
    fseek(file, peOffset + 24, SEEK_SET);  // 24 = taille du COFF header
    uint16_t magicNumber;
    if (fread(&magicNumber, sizeof(uint16_t), 1, file) != 1) {
        return false;
    }
    
    // Lire le subsystem (différent offset selon 32/64 bit)
    fseek(file, peOffset + 68, SEEK_SET);  // Offset du subsystem
    uint16_t subsystem;
    if (fread(&subsystem, sizeof(uint16_t), 1, file) != 1) {
        return false;
    }
    
    metadata.subsystem = subsystem;
    LOG_DEBUG("Subsystem: " + std::to_string(subsystem) + " (" + 
              getSubsystemDescription(subsystem) + ")");
    
    return true;
}

std::string PEAnalyzer::extractApplicationName(const std::string& filePath) {
    // Extraire le nom depuis le chemin
    size_t lastSlash = filePath.find_last_of("/\\");
    std::string filename = (lastSlash != std::string::npos) 
        ? filePath.substr(lastSlash + 1) 
        : filePath;
    
    // Enlever l'extension .exe si présente
    size_t extPos = filename.find_last_of(".");
    if (extPos != std::string::npos && filename.substr(extPos) == ".exe") {
        filename = filename.substr(0, extPos);
    }
    
    // Convertir en lowercase pour le paquet
    std::transform(filename.begin(), filename.end(), 
                   filename.begin(), ::tolower);
    
    return filename;
}

void PEAnalyzer::extractSections(FILE* file, PEMetadata& metadata) {
    fseek(file, 0x3C, SEEK_SET);
    uint32_t peOffset;
    fread(&peOffset, sizeof(uint32_t), 1, file);
    
    // Lire le nombre de sections depuis le COFF header
    fseek(file, peOffset + 6, SEEK_SET);
    uint16_t numSections;
    fread(&numSections, sizeof(uint16_t), 1, file);
    
    // Les sections commencent après le PE header + COFF header + Optional header
    fseek(file, peOffset + 24, SEEK_SET);
    uint16_t optionalHeaderSize;
    fread(&optionalHeaderSize, sizeof(uint16_t), 1, file);
    
    fseek(file, peOffset + 24 + optionalHeaderSize, SEEK_SET);
    
    // Lire les noms des sections
    char sectionName[9];
    for (uint16_t i = 0; i < numSections; i++) {
        if (fread(sectionName, 8, 1, file) != 1) {
            break;
        }
        sectionName[8] = '\0';
        metadata.sections.push_back(std::string(sectionName));
        
        // Sauter au reste de l'entry section (40 bytes total)
        fseek(file, 32, SEEK_CUR);
    }
    
    LOG_DEBUG("Sections trouvées: " + std::to_string(metadata.sections.size()));
}

std::string PEAnalyzer::getMachineTypeDescription(uint32_t type) {
    switch(type) {
        case MACHINE_I386:  return "x86 (32-bit)";
        case MACHINE_X64:   return "x86-64 (64-bit)";
        case MACHINE_ARM:   return "ARM";
        default:            return "Inconnu (0x" + std::to_string(type) + ")";
    }
}

std::string PEAnalyzer::getSubsystemDescription(uint32_t subsystem) {
    switch(subsystem) {
        case 0:  return "Système inconnu";
        case 1:  return "Pilote système native";
        case 2:  return "Application Windows GUI";
        case 3:  return "Application Windows Console";
        case 5:  return "OS/2 Console";
        case 7:  return "Posix Console";
        case 9:  return "Windows CE";
        case 10: return "Application EFI";
        default: return "Autre (" + std::to_string(subsystem) + ")";
    }
}
