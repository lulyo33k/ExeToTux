#include "package_generator.h"
#include "logger.h"
#include "elf_generator.h"
#include <cstdlib>
#include <cstdio>
#include <sys/stat.h>
#include <dirent.h>
#include <fstream>
#include <sstream>
#include <unistd.h>

PackageGenerator::PackageGenerator(const std::string& workDir) 
    : workDir(workDir) {
    
    // Créer le répertoire de travail
    mkdir(workDir.c_str(), 0755);
    LOG_DEBUG("Répertoire de travail: " + workDir);
}

PackageGenerator::~PackageGenerator() {}

bool PackageGenerator::generatePackage(const std::string& exePath,
                                       const PEMetadata& metadata,
                                       PackageFormat format,
                                       const std::string& outputPath) {
    LOG_INFO("Génération du paquet " + std::string(format == PackageFormat::DEB ? ".deb" : ".rpm"));
    
    if (format == PackageFormat::DEB) {
        return generateDebPackage(exePath, metadata, outputPath);
    } else {
        return generateRpmPackage(exePath, metadata, outputPath);
    }
}

bool PackageGenerator::generateDebPackage(const std::string& exePath,
                                          const PEMetadata& metadata,
                                          const std::string& outputPath) {
    LOG_INFO("Génération du paquet .deb");
    
    std::string packageDir = workDir + "/deb-package";
    std::string appInstallDir = packageDir + "/opt/" + metadata.appName;
    
    // Créer la structure
    if (!createPackageStructure(metadata.appName, packageDir)) {
        return false;
    }
    
    // Copier le .exe
    if (!copyExecutable(exePath, packageDir, metadata.appName)) {
        return false;
    }
    
    // Générer le wrapper ELF
    ELFGenerator elfGen;
    std::string cSourcePath = packageDir + "/launcher.c";
    std::string wrapperCode = elfGen.generateWrapperC(metadata.appName, exePath, metadata);
    
    std::ofstream cFile(cSourcePath);
    cFile << wrapperCode;
    cFile.close();
    
    std::string launcherPath = appInstallDir + "/launcher";
    if (!elfGen.compileCToELF(cSourcePath, launcherPath)) {
        lastError = elfGen.getLastError();
        return false;
    }
    
    // Créer le .desktop file
    if (!createDesktopFile(packageDir, metadata)) {
        return false;
    }
    
    // Créer le DEBIAN/control
    std::string debianDir = packageDir + "/DEBIAN";
    mkdir(debianDir.c_str(), 0755);
    
    if (!createControlFile(debianDir, metadata, calculateSize(appInstallDir))) {
        return false;
    }
    
    // Créer le script postinstall
    if (!createPostInstallScript(debianDir)) {
        return false;
    }
    
    // Construire le paquet avec dpkg-deb
    std::string command = "dpkg-deb --build " + packageDir + " " + outputPath + " 2>&1";
    
    if (!executeCommand(command)) {
        lastError = "Erreur lors de la construction du paquet .deb avec dpkg-deb";
        LOG_ERROR(lastError);
        return false;
    }
    
    LOG_INFO(".deb créé avec succès: " + outputPath);
    
    // Nettoyer
    system(("rm -rf " + packageDir).c_str());
    
    return true;
}

bool PackageGenerator::generateRpmPackage(const std::string& exePath,
                                          const PEMetadata& metadata,
                                          const std::string& outputPath) {
    LOG_INFO("Génération du paquet .rpm");
    
    std::string rpmWorkDir = workDir + "/rpm-build";
    std::string rpmDir = rpmWorkDir + "/rpmbuild";
    
    // Créer la structure rpm
    mkdir(rpmDir.c_str(), 0755);
    mkdir((rpmDir + "/SOURCES").c_str(), 0755);
    mkdir((rpmDir + "/SPECS").c_str(), 0755);
    mkdir((rpmDir + "/BUILD").c_str(), 0755);
    mkdir((rpmDir + "/RPMS").c_str(), 0755);
    mkdir((rpmDir + "/SRPMS").c_str(), 0755);
    
    std::string packageDir = rpmWorkDir + "/build";
    std::string appInstallDir = packageDir + "/opt/" + metadata.appName;
    
    // Créer la structure du paquet
    if (!createPackageStructure(metadata.appName, packageDir)) {
        return false;
    }
    
    // Copier le .exe
    if (!copyExecutable(exePath, packageDir, metadata.appName)) {
        return false;
    }
    
    // Générer le wrapper ELF
    ELFGenerator elfGen;
    std::string cSourcePath = packageDir + "/launcher.c";
    std::string wrapperCode = elfGen.generateWrapperC(metadata.appName, exePath, metadata);
    
    std::ofstream cFile(cSourcePath);
    cFile << wrapperCode;
    cFile.close();
    
    std::string launcherPath = appInstallDir + "/launcher";
    if (!elfGen.compileCToELF(cSourcePath, launcherPath)) {
        lastError = elfGen.getLastError();
        return false;
    }
    
    // Créer le fichier .desktop
    if (!createDesktopFile(packageDir, metadata)) {
        return false;
    }
    
    // Créer le spec file
    std::string specFile = rpmDir + "/SPECS/" + metadata.appName + ".spec";
    if (!createSpecFile(rpmDir, specFile, metadata)) {
        return false;
    }
    
    // Copier les fichiers pour rpmbuild
    std::string tarballPath = rpmDir + "/SOURCES/" + metadata.appName + ".tar.gz";
    std::string tarCommand = "cd " + rpmWorkDir + " && tar -czf " + tarballPath + " build/";
    executeCommand(tarCommand);
    
    // Construire le paquet RPM
    std::string rpmBuildCommand = "rpmbuild -bb --define '_topdir " + rpmDir + 
                                 "' " + specFile + " 2>&1";
    
    if (!executeCommand(rpmBuildCommand)) {
        lastError = "Erreur lors de la construction du paquet .rpm avec rpmbuild";
        LOG_ERROR(lastError);
        return false;
    }
    
    // Déplacer le RPM généré
    std::string findCommand = "find " + rpmDir + "/RPMS -name '*.rpm' -exec cp {} " + 
                             outputPath + " \\;";
    executeCommand(findCommand);
    
    LOG_INFO(".rpm créé avec succès: " + outputPath);
    
    // Nettoyer
    system(("rm -rf " + rpmWorkDir).c_str());
    
    return true;
}

bool PackageGenerator::createPackageStructure(const std::string& appName,
                                             const std::string& packageDir) {
    std::string mkdirCmd = "mkdir -p " + packageDir + "/opt/" + appName + " " +
                          packageDir + "/usr/share/applications " +
                          packageDir + "/usr/bin";
    
    if (system(mkdirCmd.c_str()) != 0) {
        lastError = "Erreur lors de la création de la structure du paquet";
        return false;
    }
    
    return true;
}

bool PackageGenerator::copyExecutable(const std::string& exePath,
                                     const std::string& packageDir,
                                     const std::string& appName) {
    std::string destPath = packageDir + "/opt/" + appName + "/app.exe";
    std::string copyCmd = "cp " + exePath + " " + destPath;
    
    if (system(copyCmd.c_str()) != 0) {
        lastError = "Erreur lors de la copie du fichier .exe";
        return false;
    }
    
    // Créer un symlink dans /usr/bin
    std::string symlinkCmd = "ln -sf /opt/" + appName + "/launcher " +
                            packageDir + "/usr/bin/" + appName;
    system(symlinkCmd.c_str());
    
    return true;
}

bool PackageGenerator::createDesktopFile(const std::string& packageDir,
                                        const PEMetadata& metadata) {
    std::string desktopPath = packageDir + "/usr/share/applications/" + 
                             metadata.appName + ".desktop";
    
    std::ofstream desktop(desktopPath);
    if (!desktop.is_open()) {
        lastError = "Erreur lors de la création du fichier .desktop";
        return false;
    }
    
    desktop << "[Desktop Entry]\n";
    desktop << "Type=Application\n";
    desktop << "Name=" << metadata.appName << "\n";
    desktop << "Comment=Windows executable wrapper - " << metadata.architecture << "\n";
    desktop << "Exec=/opt/" << metadata.appName << "/launcher\n";
    desktop << "Icon=utilities-terminal\n";
    desktop << "Terminal=true\n";
    desktop << "Categories=Utility;System;\n";
    desktop << "NoDisplay=false\n";
    
    desktop.close();
    return true;
}

bool PackageGenerator::createControlFile(const std::string& controlDir,
                                        const PEMetadata& metadata,
                                        size_t installedSize) {
    std::string controlPath = controlDir + "/control";
    
    std::ofstream control(controlPath);
    if (!control.is_open()) {
        lastError = "Erreur lors de la création du fichier control";
        return false;
    }
    
    control << "Package: " << metadata.appName << "\n";
    control << "Version: 1.0\n";
    control << "Architecture: all\n";
    control << "Maintainer: ExeToTux <auto@exetotux.local>\n";
    control << "Installed-Size: " << installedSize / 1024 << "\n";
    control << "Description: Windows executable wrapper\n";
    control << " This is an experimental wrapper created by ExeToTux.\n";
    control << " Original PE architecture: " << metadata.architecture << "\n";
    control << " File size: " << metadata.fileSize << " bytes\n";
    
    control.close();
    
    // Créer postinst
    std::string postinstPath = controlDir + "/postinst";
    std::ofstream postinst(postinstPath);
    postinst << "#!/bin/bash\n";
    postinst << "echo 'Installation de " << metadata.appName << " terminée.'\n";
    postinst << "echo 'Exécutable disponible à: /opt/" << metadata.appName << "/launcher'\n";
    postinst.close();
    chmod(postinstPath.c_str(), 0755);
    
    return true;
}

bool PackageGenerator::createSpecFile(const std::string& specDir,
                                     const std::string& specFile,
                                     const PEMetadata& metadata) {
    std::ofstream spec(specFile);
    if (!spec.is_open()) {
        lastError = "Erreur lors de la création du spec file";
        return false;
    }
    
    spec << "Name:           " << metadata.appName << "\n";
    spec << "Version:        1.0\n";
    spec << "Release:        1%{?dist}\n";
    spec << "Summary:        Windows executable wrapper\n";
    spec << "License:        MIT\n";
    spec << "BuildArch:      noarch\n";
    spec << "\n";
    spec << "%description\n";
    spec << "Experimental wrapper for Windows PE executable (" << metadata.architecture << ")\n";
    spec << "Original file size: " << metadata.fileSize << " bytes\n";
    spec << "This is a non-functional wrapper for educational purposes.\n";
    spec << "\n";
    spec << "%prep\n";
    spec << "%setup -q\n";
    spec << "\n";
    spec << "%build\n";
    spec << "# Wrapper already compiled\n";
    spec << "\n";
    spec << "%install\n";
    spec << "mkdir -p %{buildroot}/opt/" << metadata.appName << "\n";
    spec << "mkdir -p %{buildroot}/usr/bin\n";
    spec << "mkdir -p %{buildroot}/usr/share/applications\n";
    spec << "cp -r build/opt/* %{buildroot}/opt/\n";
    spec << "cp -r build/usr/* %{buildroot}/usr/\n";
    spec << "ln -sf /opt/" << metadata.appName << "/launcher %{buildroot}/usr/bin/" 
          << metadata.appName << "\n";
    spec << "\n";
    spec << "%files\n";
    spec << "/opt/" << metadata.appName << "/\n";
    spec << "/usr/bin/" << metadata.appName << "\n";
    spec << "/usr/share/applications/*.desktop\n";
    
    spec.close();
    return true;
}

bool PackageGenerator::createPostInstallScript(const std::string& packageDir) {
    // Créé dans createControlFile
    return true;
}

size_t PackageGenerator::calculateSize(const std::string& dir) {
    size_t totalSize = 0;
    DIR* dirp = opendir(dir.c_str());
    
    if (!dirp) return 0;
    
    struct dirent* entry;
    while ((entry = readdir(dirp)) != nullptr) {
        if (entry->d_type == DT_REG) {
            struct stat st;
            std::string path = dir + "/" + entry->d_name;
            if (stat(path.c_str(), &st) == 0) {
                totalSize += st.st_size;
            }
        } else if (entry->d_type == DT_DIR && 
                  entry->d_name[0] != '.' ) {
            std::string subdir = dir + "/" + entry->d_name;
            totalSize += calculateSize(subdir);
        }
    }
    
    closedir(dirp);
    return totalSize;
}

bool PackageGenerator::executeCommand(const std::string& command) {
    LOG_DEBUG("Exécution: " + command);
    int ret = system(command.c_str());
    return ret == 0;
}
