#include "reverse_converter.h"
#include "logger.h"
#include <fstream>
#include <sstream>
#include <cstdlib>
#include <cstring>
#include <filesystem>

namespace fs = std::filesystem;

ReverseConverter::ReverseConverter() {}

ReverseConverter::~ReverseConverter() {}

PackageMetadata ReverseConverter::analyzeDebPackage(const std::string& debPath) {
    LOG_INFO("Analyse du paquet DEB: " + debPath);
    PackageMetadata metadata;
    metadata.filename = fs::path(debPath).filename().string();
    
    // Vérifier que c'est un fichier .deb valide
    std::ifstream file(debPath, std::ios::binary);
    if (!file.good()) {
        metadata.isValid = false;
        metadata.errorMessage = "Impossible d'ouvrir le fichier .deb";
        LOG_ERROR(metadata.errorMessage);
        return metadata;
    }
    
    // Vérifier la signature DEB (commence par !<arch>)
    char header[8];
    file.read(header, 8);
    if (std::string(header, 8) != "!<arch>\n") {
        metadata.isValid = false;
        metadata.errorMessage = "Format .deb invalide";
        LOG_ERROR(metadata.errorMessage);
        return metadata;
    }
    
    metadata.isValid = true;
    metadata.appName = fs::path(debPath).stem().string();
    metadata.architecture = "x64";
    metadata.fileSize = fs::file_size(debPath);
    
    // Tenter d'extraire les informations du contrôle
    std::system(("dpkg -I " + debPath + " > /tmp/deb_control.txt 2>/dev/null").c_str());
    std::ifstream control("/tmp/deb_control.txt");
    std::string line;
    while (std::getline(control, line)) {
        if (line.find("Version:") != std::string::npos) {
            metadata.version = line.substr(9);
        } else if (line.find("Architecture:") != std::string::npos) {
            metadata.architecture = line.substr(14);
        } else if (line.find("Maintainer:") != std::string::npos) {
            metadata.maintainer = line.substr(12);
        } else if (line.find("Description:") != std::string::npos) {
            metadata.description = line.substr(13);
        }
    }
    
    LOG_INFO("Paquet DEB analysé: " + metadata.appName);
    return metadata;
}

PackageMetadata ReverseConverter::analyzeRpmPackage(const std::string& rpmPath) {
    LOG_INFO("Analyse du paquet RPM: " + rpmPath);
    PackageMetadata metadata;
    metadata.filename = fs::path(rpmPath).filename().string();
    
    // Vérifier que c'est un fichier .rpm valide
    std::ifstream file(rpmPath, std::ios::binary);
    if (!file.good()) {
        metadata.isValid = false;
        metadata.errorMessage = "Impossible d'ouvrir le fichier .rpm";
        LOG_ERROR(metadata.errorMessage);
        return metadata;
    }
    
    // Vérifier la signature RPM (commence par 0xEDABEEDB)
    uint32_t signature;
    file.read(reinterpret_cast<char*>(&signature), 4);
    if (signature != 0xDBEEABED) {  // Little-endian
        metadata.isValid = false;
        metadata.errorMessage = "Format .rpm invalide";
        LOG_ERROR(metadata.errorMessage);
        return metadata;
    }
    
    metadata.isValid = true;
    metadata.appName = fs::path(rpmPath).stem().string();
    metadata.architecture = "x64";
    metadata.fileSize = fs::file_size(rpmPath);
    
    // Tenter d'extraire les informations avec rpm
    std::system(("rpm -qi " + rpmPath + " > /tmp/rpm_info.txt 2>/dev/null").c_str());
    std::ifstream info("/tmp/rpm_info.txt");
    std::string line;
    while (std::getline(info, line)) {
        if (line.find("Version") != std::string::npos) {
            metadata.version = line.substr(17);
        } else if (line.find("Architecture") != std::string::npos) {
            metadata.architecture = line.substr(17);
        }
    }
    
    LOG_INFO("Paquet RPM analysé: " + metadata.appName);
    return metadata;
}

std::string ReverseConverter::generateWindowsStubC(const PackageMetadata& metadata) {
    std::stringstream ss;
    
    ss << "#include <windows.h>\n";
    ss << "#include <stdio.h>\n\n";
    ss << "int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,\n";
    ss << "                   char* pCmdLine, int nCmdShow) {\n\n";
    
    ss << "    MessageBoxA(NULL,\n";
    ss << "        \"Ce programme a été converti à partir d'un paquet Linux.\\n\\n\"\n";
    ss << "        \"Nom: " << metadata.appName << "\\n\"\n";
    ss << "        \"Version: " << metadata.version << "\\n\"\n";
    ss << "        \"Architecture: " << metadata.architecture << "\\n\"\n";
    ss << "        \"Mainteneur: " << metadata.maintainer << "\\n\\n\"\n";
    ss << "        \"⚠️ Cet exécutable n'est qu'un stub de démonstration.\\n\"\n";
    ss << "        \"Pour utiliser ce logiciel, veuillez installer le paquet Linux correspondant.\",\n";
    ss << "        \"ExeToTux - Converted Package\",\n";
    ss << "        MB_OK | MB_ICONINFORMATION);\n\n";
    
    ss << "    return 0;\n";
    ss << "}\n";
    
    return ss.str();
}

bool ReverseConverter::createPEBinaryStub(const std::string& outputPath, 
                                         const PackageMetadata& metadata) {
    LOG_INFO("Création du stub PE binaire pour: " + outputPath);
    
    std::ofstream exe(outputPath, std::ios::binary);
    if (!exe.good()) {
        lastError = "Impossible de créer le fichier .exe";
        LOG_ERROR(lastError);
        return false;
    }
    
    // DOS Header
    unsigned char dosHeader[64] = {
        0x4D, 0x5A,  // MZ
        0x90, 0x00, 0x03, 0x00, 0x00, 0x00,
        0x04, 0x00, 0x00, 0x00, 0xFF, 0xFF, 0x00, 0x00,
        0xB8, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x40, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
        0x00, 0x00, 0x00, 0x00, 0x40, 0x00, 0x00, 0x00  // PE header offset
    };
    
    exe.write(reinterpret_cast<char*>(dosHeader), 64);
    
    // DOS stub
    std::string dosStub = "This program cannot be run in DOS mode.\r\r\n$";
    exe.write(dosStub.c_str(), dosStub.length());
    
    // Padding
    while (exe.tellp() < 64) exe.put(0);
    
    // PE Signature
    exe.put('P'); exe.put('E'); exe.put(0); exe.put(0);
    
    // COFF Header
    uint16_t machine = 0x8664;  // x64
    exe.write(reinterpret_cast<char*>(&machine), 2);
    
    uint16_t sections = 3;
    exe.write(reinterpret_cast<char*>(&sections), 2);
    
    uint32_t timestamp = 0;
    exe.write(reinterpret_cast<char*>(&timestamp), 4);
    
    uint32_t pointerToSymbolTable = 0;
    exe.write(reinterpret_cast<char*>(&pointerToSymbolTable), 4);
    
    uint32_t numberOfSymbols = 0;
    exe.write(reinterpret_cast<char*>(&numberOfSymbols), 4);
    
    uint16_t sizeOfOptionalHeader = 240;
    exe.write(reinterpret_cast<char*>(&sizeOfOptionalHeader), 2);
    
    uint16_t characteristics = 0x022F;  // Executable, ASLR, NX, etc.
    exe.write(reinterpret_cast<char*>(&characteristics), 2);
    
    // Optional Header (minimal)
    uint8_t padding[240] = {0};
    padding[0] = 0x0B;  // Magic (PE32+)
    exe.write(reinterpret_cast<char*>(padding), 240);
    
    LOG_INFO("Stub PE créé avec succès");
    return true;
}

bool ReverseConverter::createWindowsStub(const std::string& packagePath, 
                                        const std::string& outputPath) {
    LOG_INFO("Création du stub Windows depuis: " + packagePath);
    
    // Déterminer le type de paquet
    bool isDeb = packagePath.find(".deb") != std::string::npos;
    
    PackageMetadata metadata = isDeb ? 
        analyzeDebPackage(packagePath) : 
        analyzeRpmPackage(packagePath);
    
    if (!metadata.isValid) {
        lastError = metadata.errorMessage;
        return false;
    }
    
    // Créer le stub PE binaire minimal
    if (!createPEBinaryStub(outputPath, metadata)) {
        return false;
    }
    
    LOG_INFO("Stub Windows créé: " + outputPath);
    return true;
}
