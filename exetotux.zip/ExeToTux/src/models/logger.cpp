#include "logger.h"

Logger::Logger() : consoleOutput(false) {}

Logger::~Logger() {
    close();
}

Logger& Logger::getInstance() {
    static Logger instance;
    return instance;
}

void Logger::init(const std::string& logFilePath, bool console) {
    consoleOutput = console;
    if (!logFilePath.empty()) {
        logFile.open(logFilePath, std::ios::app);
    }
}

void Logger::close() {
    if (logFile.is_open()) {
        logFile.close();
    }
}

std::string Logger::getTimestamp() {
    auto now = std::time(nullptr);
    auto tm = *std::localtime(&now);
    std::ostringstream oss;
    oss << std::put_time(&tm, "%Y-%m-%d %H:%M:%S");
    return oss.str();
}

std::string Logger::getLevelString(LogLevel level) {
    switch(level) {
        case LogLevel::DEBUG:    return "DEBUG";
        case LogLevel::INFO:     return "INFO";
        case LogLevel::WARNING:  return "WARNING";
        case LogLevel::ERROR:    return "ERROR";
        case LogLevel::CRITICAL: return "CRITICAL";
        default:                 return "UNKNOWN";
    }
}

void Logger::log(LogLevel level, const std::string& message) {
    std::string timestamp = getTimestamp();
    std::string levelStr = getLevelString(level);
    std::string logMsg = "[" + timestamp + "] [" + levelStr + "] " + message;
    
    if (consoleOutput) {
        std::cout << logMsg << std::endl;
    }
    
    if (logFile.is_open()) {
        logFile << logMsg << std::endl;
        logFile.flush();
    }
}
