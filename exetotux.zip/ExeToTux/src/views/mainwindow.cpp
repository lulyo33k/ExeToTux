#include "mainwindow.h"
#include "logger.h"
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGroupBox>
#include <QFileDialog>
#include <QMessageBox>
#include <QMenu>
#include <QMenuBar>
#include <QAction>
#include <QHeaderView>
#include <QIcon>
#include <QLabel>
#include <QLineEdit>
#include <QPushButton>
#include <QComboBox>
#include <QProgressBar>
#include <QTextEdit>
#include <thread>
#include <iostream>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent) {
    
    setWindowTitle("ExeToTux - PE to Linux Package Converter");
    setWindowIcon(QIcon(":/logo/exetotux-logo.png"));
    setGeometry(100, 100, 900, 700);
    
    // Initialiser le logger
    Logger::getInstance().init("/tmp/exetotux.log", true);
    LOG_INFO("Application démarrée");
    
    setupUI();
    createMenuBar();
    connectSignals();
}

MainWindow::~MainWindow() {
    LOG_INFO("Application fermée");
    Logger::getInstance().close();
}

void MainWindow::setupUI() {
    QWidget *centralWidget = new QWidget(this);
    QVBoxLayout *mainLayout = new QVBoxLayout(centralWidget);
    
    // Section 1: Sélection du fichier
    QGroupBox *fileGroupBox = new QGroupBox("1. Parcourir le fichier .EXE", this);
    QHBoxLayout *fileLayout = new QHBoxLayout(fileGroupBox);
    
    exeFilePath = new QLineEdit(this);
    exeFilePath->setPlaceholderText("Sélectionnez un fichier .exe...");
    exeFilePath->setReadOnly(true);
    
    selectExeBtn = new QPushButton("Sélectionner EXE", this);
    
    fileLayout->addWidget(new QLabel("Fichier EXE:"));
    fileLayout->addWidget(exeFilePath);
    fileLayout->addWidget(selectExeBtn);
    
    mainLayout->addWidget(fileGroupBox);
    
    // Section 2: Informations PE
    QGroupBox *peInfoGroupBox = new QGroupBox("2. Informations PE Détectées", this);
    QVBoxLayout *peInfoLayout = new QVBoxLayout(peInfoGroupBox);
    
    infoDisplay = new QTextEdit(this);
    infoDisplay->setReadOnly(true);
    infoDisplay->setMaximumHeight(200);
    
    peInfoLayout->addWidget(infoDisplay);
    
    mainLayout->addWidget(peInfoGroupBox);
    
    // Section 3: Options de sortie
    QGroupBox *outputGroupBox = new QGroupBox("3. Configuration du Paquet", this);
    QVBoxLayout *outputLayout = new QVBoxLayout(outputGroupBox);
    
    QHBoxLayout *dirLayout = new QHBoxLayout();
    outputDirPath = new QLineEdit(this);
    outputDirPath->setPlaceholderText("Sélectionnez le répertoire de sortie...");
    outputDirPath->setReadOnly(true);
    selectOutputBtn = new QPushButton("Sélectionner Sortie", this);
    dirLayout->addWidget(new QLabel("Répertoire:"));
    dirLayout->addWidget(outputDirPath);
    dirLayout->addWidget(selectOutputBtn);
    outputLayout->addLayout(dirLayout);
    
    QHBoxLayout *formatLayout = new QHBoxLayout();
    packageFormatCombo = new QComboBox(this);
    packageFormatCombo->addItem(".deb (Debian/Ubuntu)");
    packageFormatCombo->addItem(".rpm (Fedora/RedHat)");
    formatLayout->addWidget(new QLabel("Format de paquet:"));
    formatLayout->addWidget(packageFormatCombo);
    formatLayout->addStretch();
    outputLayout->addLayout(formatLayout);
    
    mainLayout->addWidget(outputGroupBox);
    
    // Section 4: Actions
    QGroupBox *actionsGroupBox = new QGroupBox("4. Actions", this);
    QHBoxLayout *actionsLayout = new QHBoxLayout(actionsGroupBox);
    
    convertBtn = new QPushButton("Lancer la Conversion", this);
    convertBtn->setStyleSheet("background-color: #4CAF50; color: white; font-weight: bold;");
    convertBtn->setMinimumHeight(40);
    
    detailedInfoBtn = new QPushButton("Infos Détaillées", this);
    detailedInfoBtn->setMinimumHeight(40);
    
    actionsLayout->addWidget(convertBtn);
    actionsLayout->addWidget(detailedInfoBtn);
    
    mainLayout->addWidget(actionsGroupBox);
    
    // Section 5: Barre de progression
    QGroupBox *progressGroupBox = new QGroupBox("Progression", this);
    QVBoxLayout *progressLayout = new QVBoxLayout(progressGroupBox);
    
    progressBar = new QProgressBar(this);
    progressBar->setMinimum(0);
    progressBar->setMaximum(100);
    progressBar->setValue(0);
    
    statusLabel = new QLabel("Prêt", this);
    statusLabel->setStyleSheet("color: #2196F3; font-weight: bold;");
    
    progressLayout->addWidget(progressBar);
    progressLayout->addWidget(statusLabel);
    
    mainLayout->addWidget(progressGroupBox);
    
    mainLayout->addStretch();
    
    setCentralWidget(centralWidget);
}

void MainWindow::createMenuBar() {
    QMenuBar *menuBar = new QMenuBar(this);
    setMenuBar(menuBar);
    
    QMenu *fileMenu = menuBar->addMenu("Fichier");
    QAction *quitAction = fileMenu->addAction("Quitter");
    connect(quitAction, &QAction::triggered, this, &QMainWindow::close);
    
    QMenu *helpMenu = menuBar->addMenu("Aide");
    QAction *aboutAction = helpMenu->addAction("À propos");
    connect(aboutAction, &QAction::triggered, this, &MainWindow::onAbout);
}

void MainWindow::connectSignals() {
    connect(selectExeBtn, &QPushButton::clicked, this, &MainWindow::onSelectExeFile);
    connect(selectOutputBtn, &QPushButton::clicked, this, &MainWindow::onSelectOutputDir);
    connect(convertBtn, &QPushButton::clicked, this, &MainWindow::onConvert);
    connect(detailedInfoBtn, &QPushButton::clicked, this, &MainWindow::onShowDetailedInfo);
}

void MainWindow::onSelectExeFile() {
    QString fileName = QFileDialog::getOpenFileName(this,
        "Sélectionner un fichier EXE", "",
        "Windows Executables (*.exe);;All Files (*)");
    
    if (!fileName.isEmpty()) {
        selectedExePath = fileName.toStdString();
        exeFilePath->setText(fileName);
        
        // Analyser le fichier PE
        PEMetadata metadata = controller.analyzeFile(selectedExePath);
        
        displayPEInfo(metadata);
        LOG_INFO("Fichier sélectionné: " + selectedExePath);
    }
}

void MainWindow::onSelectOutputDir() {
    QString dirName = QFileDialog::getExistingDirectory(this,
        "Sélectionner le répertoire de sortie", "");
    
    if (!dirName.isEmpty()) {
        selectedOutputDir = dirName.toStdString();
        outputDirPath->setText(dirName);
        LOG_INFO("Répertoire de sortie sélectionné: " + selectedOutputDir);
    }
}

void MainWindow::onConvert() {
    if (selectedExePath.empty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez sélectionner un fichier .exe");
        return;
    }
    
    if (selectedOutputDir.empty()) {
        QMessageBox::warning(this, "Erreur", "Veuillez sélectionner un répertoire de sortie");
        return;
    }
    
    convertBtn->setEnabled(false);
    statusLabel->setText("Conversion en cours...");
    progressBar->setValue(0);
    
    PackageFormat format = (packageFormatCombo->currentIndex() == 0) 
        ? PackageFormat::DEB 
        : PackageFormat::RPM;
    
    // Lancer la conversion dans un thread
    std::thread conversionThread([this, format]() {
        auto progressCallback = [this](int percent, const std::string& message) {
            QMetaObject::invokeMethod(this, [this, percent, message]() {
                onConversionProgress(percent, QString::fromStdString(message));
            });
        };
        
        bool success = controller.convert(selectedExePath, selectedOutputDir, 
                                         format, progressCallback);
        
        QMetaObject::invokeMethod(this, [this, success]() {
            convertBtn->setEnabled(true);
            if (success) {
                QMessageBox::information(this, "Succès", 
                    "Conversion réussie!\nLe paquet est prêt.");
                statusLabel->setText("Conversion réussie!");
                statusLabel->setStyleSheet("color: #4CAF50; font-weight: bold;");
            } else {
                QMessageBox::critical(this, "Erreur", 
                    QString::fromStdString("Erreur: " + controller.getLastError()));
                statusLabel->setText("Erreur!");
                statusLabel->setStyleSheet("color: #f44336; font-weight: bold;");
            }
        });
    });
    
    conversionThread.detach();
}

void MainWindow::onShowDetailedInfo() {
    if (selectedExePath.empty()) {
        QMessageBox::warning(this, "Information", "Veuillez d'abord sélectionner un fichier .exe");
        return;
    }
    
    QString report = QString::fromStdString(
        controller.generateComparisonReport(selectedExePath, "")
    );
    
    QMessageBox::information(this, "Rapport Détaillé PE vs ELF", report);
}

void MainWindow::onAbout() {
    QMessageBox::information(this, "À propos",
        "ExeToTux v1.0\n\n"
        "Outil expérimental pour convertir les fichiers .exe Windows\n"
        "en paquets Linux installables (.deb, .rpm)\n\n"
        "⚠️ Avertissement: L'exécutable final ne sera pas fonctionnel.\n"
        "Cet outil est pédagogique et expérimental.\n\n"
        "Auteur: ExeToTux Team");
}

void MainWindow::onConversionProgress(int percent, const QString& message) {
    progressBar->setValue(percent);
    statusLabel->setText(message);
}

void MainWindow::displayPEInfo(const PEMetadata& metadata) {
    QString info;
    
    if (!metadata.isValid) {
        info = "❌ Fichier PE non valide\nErreur: " + 
               QString::fromStdString(metadata.errorMessage);
    } else {
        info = "✓ Fichier PE valide\n\n";
        info += "📦 Application: " + QString::fromStdString(metadata.appName) + "\n";
        info += "🏗️  Architecture: " + QString::fromStdString(metadata.architecture) + "\n";
        info += "💾 Taille: " + QString::number(metadata.fileSize) + " bytes\n";
        info += "📋 Subsystem: " + 
                QString::fromStdString(PEAnalyzer::getSubsystemDescription(metadata.subsystem)) + "\n";
        info += "📌 Sections: " + QString::number(metadata.sections.size()) + "\n";
    }
    
    infoDisplay->setPlainText(info);
}
