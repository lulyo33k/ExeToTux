#ifndef PACKAGE_GENERATOR_H
#define PACKAGE_GENERATOR_H

#include <string>
#include <vector>
#include "pe_analyzer.h"

enum class PackageFormat {
    DEB,
    RPM
};

/**
 * Génère des paquets Linux (.deb ou .rpm)
 * contenant le wrapper ELF et le .exe
 */
class PackageGenerator {
public:
    PackageGenerator(const std::string& workDir = "/tmp/exetotux");
    ~PackageGenerator();
    
    /**
     * Génère un paquet complet
     * @param exePath Chemin vers le fichier .exe source
     * @param metadata Métadonnées PE analysées
     * @param format Format du paquet (DEB ou RPM)
     * @param outputPath Chemin de sortie du paquet
     * @return true si succès
     */
    bool generatePackage(const std::string& exePath, 
                        const PEMetadata& metadata,
                        PackageFormat format,
                        const std::string& outputPath);
    
    /**
     * Génère un paquet .deb
     */
    bool generateDebPackage(const std::string& exePath,
                           const PEMetadata& metadata,
                           const std::string& outputPath);
    
    /**
     * Génère un paquet .rpm
     */
    bool generateRpmPackage(const std::string& exePath,
                           const PEMetadata& metadata,
                           const std::string& outputPath);
    
    /**
     * Obtient le dernier message d'erreur
     */
    std::string getLastError() const { return lastError; }
    
private:
    std::string workDir;
    std::string lastError;
    
    /**
     * Crée la structure de répertoires du paquet
     */
    bool createPackageStructure(const std::string& appName,
                               const std::string& packageDir);
    
    /**
     * Copie le .exe dans le paquet
     */
    bool copyExecutable(const std::string& exePath,
                       const std::string& packageDir,
                       const std::string& appName);
    
    /**
     * Crée le fichier .desktop
     */
    bool createDesktopFile(const std::string& packageDir,
                          const PEMetadata& metadata);
    
    /**
     * Crée le fichier control pour .deb
     */
    bool createControlFile(const std::string& controlDir,
                          const PEMetadata& metadata,
                          size_t installedSize);
    
    /**
     * Crée le spec file pour .rpm
     */
    bool createSpecFile(const std::string& specDir,
                       const std::string& specFile,
                       const PEMetadata& metadata);
    
    /**
     * Crée le script post-install
     */
    bool createPostInstallScript(const std::string& packageDir);
    
    /**
     * Calcule la taille du paquet
     */
    size_t calculateSize(const std::string& dir);
    
    /**
     * Exécute une commande shell
     */
    bool executeCommand(const std::string& command);
};

#endif // PACKAGE_GENERATOR_H
