#ifndef CONVERSION_CONTROLLER_H
#define CONVERSION_CONTROLLER_H

#include <string>
#include <functional>
#include "pe_analyzer.h"
#include "package_generator.h"
#include "elf_generator.h"

/**
 * Contrôleur principal pour l'orchestration
 * de la conversion EXE -> paquet Linux
 */
class ConversionController {
public:
    using ProgressCallback = std::function<void(int, const std::string&)>;
    
    ConversionController();
    ~ConversionController();
    
    /**
     * Lance le processus complet de conversion
     * @param exePath Chemin du fichier .exe
     * @param outputDir Répertoire de sortie
     * @param format Format du paquet (DEB ou RPM)
     * @param progressCallback Callback pour les mises à jour
     * @return true si succès
     */
    bool convert(const std::string& exePath,
                 const std::string& outputDir,
                 PackageFormat format,
                 ProgressCallback progressCallback = nullptr);
    
    /**
     * Obtient les métadonnées du dernier fichier analysé
     */
    const PEMetadata& getLastMetadata() const { return lastMetadata; }
    
    /**
     * Analyse un fichier PE et retourne ses métadonnées
     */
    PEMetadata analyzeFile(const std::string& exePath) {
        lastMetadata = peAnalyzer.analyzeFile(exePath);
        return lastMetadata;
    }
    
    /**
     * Obtient le dernier message d'erreur
     */
    std::string getLastError() const { return lastError; }
    
    /**
     * Crée un rapport de comparaison PE vs ELF
     */
    std::string generateComparisonReport(const std::string& peFilePath,
                                         const std::string& elfFilePath);

private:
    PEMetadata lastMetadata;
    std::string lastError;
    PEAnalyzer peAnalyzer;
    PackageGenerator packageGenerator;
    ELFGenerator elfGenerator;
    
    /**
     * Helper pour mettre à jour la progression
     */
    void reportProgress(int percent, const std::string& message,
                       ProgressCallback& callback);
};

#endif // CONVERSION_CONTROLLER_H
