#ifndef PE_ANALYZER_H
#define PE_ANALYZER_H

#include <string>
#include <vector>
#include <cstdint>
#include <map>

/**
 * Structure pour stocker les métadonnées du PE
 */
struct PEMetadata {
    std::string filename;
    std::string appName;
    std::string version;
    std::string architecture;  // x86, x64, arm
    uint32_t machineType;
    uint32_t subsystem;
    size_t fileSize;
    bool isValid;
    std::string errorMessage;
    
    // Ressources
    bool hasIcon;
    std::vector<uint8_t> iconData;
    
    // Sections
    std::vector<std::string> sections;
};

/**
 * Analyseur de fichiers PE (Portable Executable)
 * Format Windows exécutables
 */
class PEAnalyzer {
public:
    PEAnalyzer();
    ~PEAnalyzer();
    
    /**
     * Analyse un fichier .exe
     * @param filePath Chemin vers le fichier .exe
     * @return Métadonnées extraites
     */
    PEMetadata analyzeFile(const std::string& filePath);
    
    /**
     * Obtient la description d'une architecture machine
     */
    static std::string getMachineTypeDescription(uint32_t type);
    
    /**
     * Obtient la description d'un subsystem
     */
    static std::string getSubsystemDescription(uint32_t subsystem);
    
private:
    /**
     * Lit et valide le header DOS
     */
    bool validateDOSHeader(FILE* file);
    
    /**
     * Lit et valide le header PE
     */
    bool validatePEHeader(FILE* file, PEMetadata& metadata);
    
    /**
     * Extrait le nom depuis le fichier ou les métadonnées
     */
    std::string extractApplicationName(const std::string& filePath);
    
    /**
     * Extrait les sections du PE
     */
    void extractSections(FILE* file, PEMetadata& metadata);
};

#endif // PE_ANALYZER_H
