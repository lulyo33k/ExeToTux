#ifndef REVERSE_CONVERTER_H
#define REVERSE_CONVERTER_H

#include <string>
#include "pe_analyzer.h"

/**
 * Structure pour les métadonnées de paquet Linux
 */
struct PackageMetadata {
    std::string filename;
    std::string appName;
    std::string version;
    std::string architecture;
    std::string maintainer;
    std::string description;
    size_t fileSize;
    bool isValid;
    std::string errorMessage;
};

/**
 * Convertisseur inverse : Linux -> Windows PE
 * Permet de créer un pseudo-.exe stub à partir d'un paquet Linux
 */
class ReverseConverter {
public:
    ReverseConverter();
    ~ReverseConverter();
    
    /**
     * Analyse un paquet .deb
     * @param debPath Chemin vers le fichier .deb
     * @return Métadonnées extraites
     */
    PackageMetadata analyzeDebPackage(const std::string& debPath);
    
    /**
     * Analyse un paquet .rpm
     * @param rpmPath Chemin vers le fichier .rpm
     * @return Métadonnées extraites
     */
    PackageMetadata analyzeRpmPackage(const std::string& rpmPath);
    
    /**
     * Crée un stub .exe Windows à partir d'un paquet Linux
     * Le stub est un PE valide qui affiche un message lors de l'exécution
     * @param packagePath Chemin du paquet (.deb ou .rpm)
     * @param outputPath Chemin de sortie du .exe
     * @return true si succès
     */
    bool createWindowsStub(const std::string& packagePath, const std::string& outputPath);
    
    /**
     * Obtient le dernier message d'erreur
     */
    std::string getLastError() const { return lastError; }

private:
    std::string lastError;
    
    /**
     * Génère un stub PE minimal en C
     */
    std::string generateWindowsStubC(const PackageMetadata& metadata);
    
    /**
     * Compile le C en .exe avec MinGW (si disponible)
     */
    bool compileStubToExe(const std::string& cSourcePath, 
                          const std::string& outputExePath);
    
    /**
     * Crée un PE stub valide binaire
     */
    bool createPEBinaryStub(const std::string& outputPath, 
                           const PackageMetadata& metadata);
};

#endif // REVERSE_CONVERTER_H
