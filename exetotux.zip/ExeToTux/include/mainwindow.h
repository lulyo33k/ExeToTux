#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QProgressBar>
#include <QPushButton>
#include <QLabel>
#include <QLineEdit>
#include <QComboBox>
#include <QTextEdit>
#include <QTableWidget>
#include "conversion_controller.h"

/**
 * Fenêtre principale de l'interface GUI Qt
 */
class MainWindow : public QMainWindow {
    Q_OBJECT
    
public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();
    
private slots:
    void onSelectExeFile();
    void onSelectOutputDir();
    void onConvert();
    void onShowDetailedInfo();
    void onAbout();
    void onConversionProgress(int percent, const QString& message);
    
private:
    void setupUI();
    void createMenuBar();
    void createCentralWidget();
    void connectSignals();
    void displayPEInfo(const PEMetadata& metadata);
    
    // Composants UI
    QLineEdit* exeFilePath;
    QLineEdit* outputDirPath;
    QComboBox* packageFormatCombo;
    QPushButton* selectExeBtn;
    QPushButton* selectOutputBtn;
    QPushButton* convertBtn;
    QPushButton* detailedInfoBtn;
    QProgressBar* progressBar;
    QLabel* statusLabel;
    QTextEdit* infoDisplay;
    QTableWidget* peInfoTable;
    
    // Contrôleur
    ConversionController controller;
    
    // État de l'application
    std::string selectedExePath;
    std::string selectedOutputDir;
};

#endif // MAINWINDOW_H
