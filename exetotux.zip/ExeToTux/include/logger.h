#ifndef LOGGER_H
#define LOGGER_H

#include <string>
#include <fstream>
#include <iostream>
#include <ctime>
#include <iomanip>
#include <sstream>

enum class LogLevel {
    DEBUG,
    INFO,
    WARNING,
    ERROR,
    CRITICAL
};

/**
 * Système de journalisation centralié
 */
class Logger {
public:
    static Logger& getInstance();
    
    /**
     * Initialise le logger avec un fichier de sortie
     */
    void init(const std::string& logFilePath, bool consoleOutput = true);
    
    /**
     * Log un message
     */
    void log(LogLevel level, const std::string& message);
    
    /**
     * Raccourcis pour chaque niveau de log
     */
    void debug(const std::string& message) { log(LogLevel::DEBUG, message); }
    void info(const std::string& message) { log(LogLevel::INFO, message); }
    void warning(const std::string& message) { log(LogLevel::WARNING, message); }
    void error(const std::string& message) { log(LogLevel::ERROR, message); }
    void critical(const std::string& message) { log(LogLevel::CRITICAL, message); }
    
    /**
     * Ferme le logger
     */
    void close();
    
private:
    Logger();
    ~Logger();
    
    Logger(const Logger&) = delete;
    Logger& operator=(const Logger&) = delete;
    
    std::ofstream logFile;
    bool consoleOutput;
    
    /**
     * Retourne le timestamp formaté
     */
    std::string getTimestamp();
    
    /**
     * Retourne le label du niveau de log
     */
    std::string getLevelString(LogLevel level);
};

#define LOG_DEBUG(msg)    Logger::getInstance().debug(msg)
#define LOG_INFO(msg)     Logger::getInstance().info(msg)
#define LOG_WARNING(msg)  Logger::getInstance().warning(msg)
#define LOG_ERROR(msg)    Logger::getInstance().error(msg)
#define LOG_CRITICAL(msg) Logger::getInstance().critical(msg)

#endif // LOGGER_H
