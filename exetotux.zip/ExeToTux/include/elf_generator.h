#ifndef ELF_GENERATOR_H
#define ELF_GENERATOR_H

#include <string>
#include <vector>
#include "pe_analyzer.h"

/**
 * Génère un wrapper ELF minimal en C
 * qui embarque et affiche un message au lieu d'exécuter le .exe
 */
class ELFGenerator {
public:
    ELFGenerator();
    ~ELFGenerator();
    
    /**
     * Génère le code C source du wrapper
     * @param appName Nom de l'application
     * @param exePath Chemin vers le .exe
     * @param metadata Métadonnées PE
     * @return Code C généralisé
     */
    std::string generateWrapperC(const std::string& appName,
                                 const std::string& exePath,
                                 const PEMetadata& metadata);
    
    /**
     * Compile le code C en binaire ELF
     * @param cFilePath Chemin vers le fichier .c
     * @param outputPath Chemin du binaire de sortie
     * @param optimizationLevel Niveau d'optimisation (-O0, -O2, etc)
     * @return true si succès
     */
    bool compileCToELF(const std::string& cFilePath,
                       const std::string& outputPath,
                       const std::string& optimizationLevel = "-O2");
    
    /**
     * Obtient le dernier message d'erreur
     */
    std::string getLastError() const { return lastError; }
    
private:
    std::string lastError;
    
    /**
     * Génère l'en-tête du fichier C avec includes et structures
     */
    std::string generateCHeader(const std::string& appName);
    
    /**
     * Génère la fonction main du wrapper
     */
    std::string generateCMain(const std::string& appName,
                             const PEMetadata& metadata);
    
    /**
     * Vérifie si gcc/clang est disponible
     */
    bool checkCompiler();
    
    /**
     * Exécute une commande shell
     */
    bool executeCommand(const std::string& command);
};

#endif // ELF_GENERATOR_H
