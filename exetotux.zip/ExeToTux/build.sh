#!/usr/bin/env bash

# Script de build pour ExeToTux
# Construit l'application en mode release

set -e

echo "════════════════════════════════════════════"
echo "   ExeToTux - Build Script"
echo "════════════════════════════════════════════"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"
INSTALL_DIR="${SCRIPT_DIR}/install"

# Créer les répertoires
mkdir -p "${BUILD_DIR}"
mkdir -p "${INSTALL_DIR}"

echo "📁 Directories créés"
echo "  Build: ${BUILD_DIR}"
echo "  Install: ${INSTALL_DIR}"

# Configurer avec CMake
echo ""
echo "🔧 Configuration CMake..."
cd "${BUILD_DIR}"
cmake -DCMAKE_BUILD_TYPE=Release \
      -DCMAKE_PREFIX_PATH=/usr/lib/qt6 \
      -DCMAKE_INSTALL_PREFIX="${INSTALL_DIR}" \
      ..

# Compiler
echo ""
echo "🔨 Compilation..."
make -j$(nproc)

# Installer
echo ""
echo "📦 Installation..."
make install

echo ""
echo "✅ Build Complète!"
echo ""
echo "Exécutables:"
echo "  GUI: ${INSTALL_DIR}/bin/exetotux-gui"
echo "  CLI: ${INSTALL_DIR}/bin/exetotux-cli"
echo ""
echo "Pour lancer l'application GUI:"
echo "  ${INSTALL_DIR}/bin/exetotux-gui"
echo ""
