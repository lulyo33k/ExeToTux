# Fichier de configuration pour ExeToTux Build

# Chemin vers les sources
SOURCES_DIR=$(pwd)

# Répertoires de sortie
BUILD_DIR="${SOURCES_DIR}/build"
INSTALL_PREFIX="${SOURCES_DIR}/install"
PACKAGE_OUTPUT="${SOURCES_DIR}"

# Détection de la distribution Linux
if [ -f /etc/os-release ]; then
    . /etc/os-release
    DISTRO=$ID
else
    DISTRO="unknown"
fi

# Paramètres CMake
CMAKE_BUILD_TYPE="Release"
CMAKE_CXX_FLAGS="-Wall -Wextra -O2"

# Paramètres Qt
QT_VERSION="6"
QT_PATH="/usr/lib/cmake/Qt${QT_VERSION}"

# Paramètres de compilation
JOBS=$(nproc)
VERBOSE=0

# Options de packaging
DEB_ENABLE=1
RPM_ENABLE=1
STRIP_BINARIES=1

# Options de signature (GPG)
SIGN_PACKAGES=0
GPG_KEY=""

# Système de sécurité
BUILD_WITH_ASAN=0  # Address Sanitizer
BUILD_WITH_UBSAN=0 # Undefined Behavior Sanitizer

# Logging
LOG_LEVEL="INFO"  # DEBUG, INFO, WARNING, ERROR
LOG_FILE="${BUILD_DIR}/build.log"

# Version
VERSION_MAJOR=1
VERSION_MINOR=0
VERSION_PATCH=0
VERSION_SUFFIX=""

export SOURCES_DIR BUILD_DIR INSTALL_PREFIX DISTRO CMAKE_BUILD_TYPE JOBS
