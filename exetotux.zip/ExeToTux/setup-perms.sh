#!/bin/bash

# Script pour initialiser les permissions des fichiers de build

set -e

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "📋 Configuration des permissions..."

chmod +x "${SCRIPT_DIR}/build.sh"
echo "  ✓ build.sh"

chmod +x "${SCRIPT_DIR}/build-deb.sh"
echo "  ✓ build-deb.sh"

chmod +x "${SCRIPT_DIR}/build-rpm.sh"
echo "  ✓ build-rpm.sh"

# Rendre les fichiers source exécutables en lecture
chmod 644 "${SCRIPT_DIR}"/*.md
echo "  ✓ Documentation"

chmod 644 "${SCRIPT_DIR}"/CMakeLists.txt
echo "  ✓ CMakeLists.txt"

echo ""
echo "✅ Permissions configurées!"
echo ""
echo "Pour démarrer le build:"
echo "  cd ${SCRIPT_DIR}"
echo "  ./build.sh"
