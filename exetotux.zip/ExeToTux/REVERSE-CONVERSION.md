# Conversion Inverse : DEB/RPM → Windows EXE

## 📌 Aperçu

ExeToTux inclut maintenant une **fonctionnalité de conversion inverse** qui permet de créer des stubs Windows .exe à partir de paquets Linux (.deb/.rpm).

Cette fonctionnalité est utile pour :
- 📦 Distribuer des paquets Linux à des utilisateurs Windows
- 🔄 Fournir un pointeur vers la version Linux
- 🧪 Tester l'intégrité des paquets créés
- 📋 Documenter la provenance des paquets

## 🚀 Utilisation CLI

### Créer un stub EXE depuis un paquet DEB

```bash
exetotux-cli --reverse-convert /path/to/package.deb -o output.exe
```

### Créer un stub EXE depuis un paquet RPM

```bash
exetotux-cli --reverse-convert /path/to/package.rpm -o output.exe
```

## 🔍 Classes Principales

### ReverseConverter

Classe responsable de la conversion inverse :

```cpp
#include "reverse_converter.h"

ReverseConverter converter;

// Analyser un paquet DEB
PackageMetadata deb_meta = converter.analyzeDebPackage("application.deb");

// Analyser un paquet RPM  
PackageMetadata rpm_meta = converter.analyzeRpmPackage("application.rpm");

// Créer un stub EXE
bool success = converter.createWindowsStub(
    "application.deb", 
    "application.exe"
);

if (!success) {
    std::cerr << "Erreur: " << converter.getLastError() << std::endl;
}
```

### PackageMetadata

Structure contenant les métadonnées extraites :

```cpp
struct PackageMetadata {
    std::string filename;        // Nom du fichier
    std::string appName;         // Nom de l'application
    std::string version;         // Version du paquet
    std::string architecture;    // Architecture CPU
    std::string maintainer;      // Mainteneur du paquet
    std::string description;     // Description
    size_t fileSize;            // Taille en bytes
    bool isValid;               // Validité du paquet
    std::string errorMessage;   // Message d'erreur si invalide
};
```

## 📁 Fichiers du Projet

```
include/
  └─ reverse_converter.h       # Header de la classe inverse

src/models/
  └─ reverse_converter.cpp     # Implémentation

scripts/
  └─ create-test-exe.sh        # Script pour générer un .exe test

sample-program.exe             # Ficier .exe test fourni
```

## ⚙️ Détails Techniques

### Analyse DEB

1. Valide la signature `!<arch>\n` au début du fichier
2. Extrait les métadonnées via `dpkg -I`
3. Parse les champs Version, Architecture, Description

### Analyse RPM

1. Valide la signature COFF `0xEDABEEDB`
2. Extrait les métadonnées via `rpm -qi`
3. Parse les informations disponibles

### Génération de Stub PE

Le stub .exe généré contient :

- **DOS Header** : Signature MZ valide
- **DOS Stub** : Message d'erreur standard
- **PE Signature** : Identifiant portable executable
- **COFF Header** : Architecture x64 (0x8664)
- **Optional Header** : Informations d'exécution minimales
- **Sections PE** : .text, .data, .rsrc (valides mais vides)

### Métadonnées Intégrées

Les stubs créés peuvent inclure :
- Nom de l'application
- Version du paquet
- Architecture CPU
- Nom du mainteneur
- Description du paquet

## 🧪 Test Inclus

Un fichier `sample-program.exe` est fourni pour tester la fonctionnalité :

```bash
# Tester l'analyse du paquet DEB créé  
exetotux-cli --analyze sample-program.exe

# Créer un paquet depuis le test program
exetotux-cli --input sample-program.exe -f deb -o test-package.deb

# Puis convertir le paquet DEB en EXE
exetotux-cli --reverse-convert test-package.deb -o output.exe
```

## ✅ Exemple Complet

```bash
#!/bin/bash

# 1. Construire l'application
mkdir -p /tmp/test-app
echo "#!/bin/bash
echo 'Hello from Linux!" > /tmp/test-app/hello.sh
chmod +x /tmp/test-app/hello.sh

# 2. Créer un paquet DEB
dpkg-deb --build /tmp/test-app test-app.deb

# 3. Convertir en EXE Windows
exetotux-cli --reverse-convert test-app.deb -o windows-version.exe

# 4. Vérifier les métadonnées
file windows-version.exe
exetotux-cli --analyze windows-version.exe
```

## 📝 Notes Importantes

⚠️ **Le stub EXE créé est non-fonctionnel sur Windows.** Il s'agit uniquement d'un conteneur d'informations qui :

- Affiche un message lors de l'exécution sur Windows
- Fournit les métadonnées du paquet Linux
- Propose à l'utilisateur la version Linux

😊 **L'objectif est pédagogique et expérimental**, pas une véritable virtualisation ou emulation.

## 🔗 Connexions

- **PEAnalyzer** : Classe sœur pour l'analyse des .exe
- **PackageGenerator** : Crée les paquets DEB/RPM
- **ConversionController** : Orchestrateur principal

## 📚 Ressources

- Format PE : https://en.wikipedia.org/wiki/Portable_Executable
- Format DEB : https://www.debian.org/doc/debian-policy/
- Format RPM : https://rpm.org/
