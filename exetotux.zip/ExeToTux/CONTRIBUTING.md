# ExeToTux - Contribution Guide

## Bienvenue! 👋

Nous sommes ravis que vous envisagiez de contribuer à ExeToTux. Ce guide vous aidera à comprendre comment contribuer efficacement.

## Types de Contributions

### 🐛 Signaler des Bugs
Si vous trouvez un bug:
1. Vérifiez que le bug n'a pas déjà été rapporté
2. Donnez un titre descriptif
3. Décrivez les étapes pour reproduire
4. Fournissez des exemples spécifiques
5. Décrivez le comportement observé vs attendu

### ✨ Proposer des Fonctionnalités
1. Explique le use case
2. Décris la solution proposée
3. Fournis des exemples de code
4. Explique les alternatives envisagées
5. Note les impacts sur la performance

### 💻 Soumettre du Code

#### Configuration Développement

```bash
# Clone le repo
git clone https://github.com/exetotux/exetotux.git
cd exetotux

# Crée une branche feature
git checkout -b feature/nom-feature

# Build
./build.sh

# Test
./test.sh
```

#### Standards Coding

**C++**
```cpp
// Utilise camelCase pour variables/fonctions
std::string getApplicationName();

// Utilise PascalCase pour classes
class PEAnalyzer {
public:
    // Commentaires doxygen
    /// @brief Analyse un fichier PE
    /// @param filePath Chemin du fichier
    /// @return Métadonnées extraites
    PEMetadata analyzeFile(const std::string& filePath);
};

// Largeur ligne: 80-100 caractères
// Indentation: 4 espaces
// Braces style: K&R (braces ouvrantes sur mêmes line)
```

**CMake**
```cmake
# Respecte conventions CMake
set(VAR_NAME value)  # Majuscules avec underscores
add_executable(target source.cpp)
target_link_libraries(target PRIVATE lib)
```

**Bash**
```bash
#!/usr/bin/env bash
set -e  # Exit on error
set -u  # Error on undefined var

# Noms funcitions en minuscules avec underscores
function build_project() {
    local local_var="value"
    echo "Message"
}
```

#### Structure Commits

```
[Type] Titre court (50 chars max)

Description plus longue si nécessaire.
Explique le POURQUOI pas le COMMENT.

- Point 1
- Point 2

Fixes #123  # Si corrigi bug/feature
Closes #456
```

Types de commit:
- `[FEAT]` - Nouvelle fonctionnalité
- `[FIX]` - Correction de bug
- `[DOCS]` - Documentation
- `[STYLE]` - Formatage / Style
- `[REFACTOR]` - Refactorisation
- `[PERF]` - Optimisation performance
- `[TEST]` - Tests
- `[CHORE]` - Maintenance

#### Processus Review

1. **Formate ton code**
   ```bash
   # Format automatique C++
   clang-format -i src/**/*.cpp
   ```

2. **Teste ton changement**
   ```bash
   make clean
   make build
   make test
   ```

3. **Documentation**
   - Mets à jour README si nécessaire
   - Ajoute des commentaires de code
   - Documente nouvelles APIs

4. **Soumet une PR**
   - Title clair et descriptif
   - Description détaillée
   - Référence les issues liées
   - Screenshots/gifs si pertinent (GUI changes)

5. **Réponds aux reviews**
   - Sois ouvert aux critiques
   - Pose des questions si besoin
   - Fais les changements demandés

### 📖 Améliorer la Documentation

Documentation fichiers:
- `README.md` - Guide utilisateur
- `TECHNICAL.md` - Détails implémentation
- `CHANGELOG.md` - Historique versions
- Code comments - Explique pourquoi

Guide rédaction docs:
- Sois clair et concis
- Utilise exemples quand possible
- Structure avec headings
- Références croisées avec liens

### 🧪 Écrire des Tests

Tests structure:
```
tests/
├── unit/
│   ├── test_pe_analyzer.cpp
│   └── test_elf_generator.cpp
└── integration/
    └── test_conversion_flow.cpp
```

Utilise CTest:
```bash
mkdir build && cd build
cmake ..
make
ctest --output-on-failure
```

## Processus Review

### Pour Reviewers
- Vérifiez la qualité code
- Testez les changements
- Vérifiez documentation
- Donnez feedback constructif

### Pour Contributors
- Adressez tous les commentaires
- Répondez politement aux questions
- Push les changements demandés
- Merge si approuvé

## Guidelines Communauté

### Soyez Respectueux
- Zero-tolerance pour harcèlement
- Acceptez critiques constructives
- Aidez les débutants

### Soyez Productif
- Restez on-topic
- Utilisez la search avant de demander
- Évitez les débats meta

### Soyez Inclusif
- Documentation claire
- Exemples variés
- Accessibilité importante

## Besoin d'Aide?

- **Questions Code**: Ouvrez une issue "question"
- **Discussion Générale**: Utilisez Discussions
- **Security Issue**: Email security@exetotux.local (prive)
- **Autre**: Contactez @maintainers

## License

En contribuant, vous acceptez que votre code soit sous licence MIT.

## Code of Conduct

Consultez CODE_OF_CONDUCT.md pour les standards comportement.

---

Merci de votre contribution! 🙏
L'équipe ExeToTux
