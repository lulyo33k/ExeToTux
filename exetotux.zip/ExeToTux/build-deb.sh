#!/usr/bin/env bash

# Script de création du paquet .deb pour ExeToTux

set -e

echo "════════════════════════════════════════════"
echo "   ExeToTux - DEB Package Builder"
echo "════════════════════════════════════════════"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"
PACKAGE_DIR="${SCRIPT_DIR}/deb-package"
VERSION="1.0.0"
ARCH="amd64"

# Nettoyer
rm -rf "${PACKAGE_DIR}"

# Créer la structure du paquet
echo "📁 Création de la structure du paquet..."
mkdir -p "${PACKAGE_DIR}/DEBIAN"
mkdir -p "${PACKAGE_DIR}/usr/bin"
mkdir -p "${PACKAGE_DIR}/usr/share/applications"
mkdir -p "${PACKAGE_DIR}/usr/share/doc/exetotux"

# Copier les exécutables
if [ ! -f "${BUILD_DIR}/exetotux-gui" ] || [ ! -f "${BUILD_DIR}/exetotux-cli" ]; then
    echo "❌ Les exécutables n'ont pas été trouvés. Compilez d'abord avec ./build.sh"
    exit 1
fi

echo "📋 Copie des exécutables..."
cp "${BUILD_DIR}/exetotux-gui" "${PACKAGE_DIR}/usr/bin/exetotux-gui"
cp "${BUILD_DIR}/exetotux-cli" "${PACKAGE_DIR}/usr/bin/exetotux-cli"
chmod 755 "${PACKAGE_DIR}/usr/bin/exetotux-gui"
chmod 755 "${PACKAGE_DIR}/usr/bin/exetotux-cli"

# Créer un symlink
ln -sf exetotux-gui "${PACKAGE_DIR}/usr/bin/exetotux"

# Copier le fichier .desktop
echo "🎨 Copie du fichier .desktop..."
cp "${SCRIPT_DIR}/packaging/exetotux.desktop" \
   "${PACKAGE_DIR}/usr/share/applications/exetotux.desktop"

# Créer le fichier de contrôle
echo "📝 Création du fichier control..."
cat > "${PACKAGE_DIR}/DEBIAN/control" <<EOF
Package: exetotux
Version: ${VERSION}
Architecture: ${ARCH}
Maintainer: ExeToTux Team <dev@exetotux.local>
Depends: libc6 (>= 2.31), libqt6core6 (>= 6.0), libqt6gui6 (>= 6.0), libqt6widgets6 (>= 6.0), dpkg, rpm, gcc
Installed-Size: $(du -s "${PACKAGE_DIR}" | cut -f1)
Homepage: https://github.com/exetotux/exetotux
Description: PE to Linux Package Converter
 ExeToTux is an experimental tool for converting Windows PE executables
 into installable Linux packages (.deb, .rpm).
 .
 Features:
  - Analyze PE file format
  - Extract metadata (architecture, subsystem)
  - Generate ELF wrapper
  - Create installable packages
 .
 Warning: The resulting executable will not be functional.
 This is an educational and experimental tool.
EOF

# Créer le script d'installation post
echo "🔧 Création du script postinst..."
cat > "${PACKAGE_DIR}/DEBIAN/postinst" <<'EOF'
#!/bin/bash
set -e

if [ "$1" = "configure" ]; then
    chmod 755 /usr/bin/exetotux-gui
    chmod 755 /usr/bin/exetotux-cli
    
    # Créer les répertoires de travail s'ils n'existent pas
    mkdir -p /tmp/exetotux
    chmod 777 /tmp/exetotux
    
    echo "ExeToTux installed successfully!"
    echo "Run 'exetotux-gui' to start the GUI or 'exetotux-cli --help' for CLI help"
fi

exit 0
EOF
chmod 755 "${PACKAGE_DIR}/DEBIAN/postinst"

# Créer le script de pré-suppression
echo "🧹 Création du script prerm..."
cat > "${PACKAGE_DIR}/DEBIAN/prerm" <<'EOF'
#!/bin/bash
set -e

if [ "$1" = "remove" ]; then
    echo "Removing ExeToTux..."
fi

exit 0
EOF
chmod 755 "${PACKAGE_DIR}/DEBIAN/prerm"

# Créer le fichier copyright
echo "📄 Création du fichier copyright..."
cat > "${PACKAGE_DIR}/usr/share/doc/exetotux/copyright" <<EOF
Format: https://www.debian.org/doc/packaging-manuals/copyright-format/1.0/
Upstream-Name: ExeToTux
Upstream-Contact: ExeToTux Team

Files: *
Copyright: 2025 ExeToTux Team
License: MIT

License: MIT
 Permission is hereby granted, free of charge, to any person obtaining a copy
 of this software and associated documentation files (the "Software"), to deal
 in the Software without restriction, including without limitation the rights
 to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:
 .
 The above copyright notice and this permission notice shall be included in all
 copies or substantial portions of the Software.
EOF

# Créer le fichier CHANGELOG
cat > "${PACKAGE_DIR}/usr/share/doc/exetotux/changelog.Debian" <<EOF
exetotux (${VERSION}-1) unstable; urgency=low

  * Initial release
  * PE analysis functionality
  * DEB and RPM package generation
  * Qt GUI and CLI interfaces
  * ELF wrapper generation

 -- ExeToTux Team <dev@exetotux.local>  $(date -R)
EOF

# Calculer la taille installée
INSTALLED_SIZE=$(du -s "${PACKAGE_DIR}" | cut -f1)

# Construire le paquet
echo ""
echo "🔨 Construction du paquet .deb..."
OUTPUT_DEB="${SCRIPT_DIR}/exetotux_${VERSION}_${ARCH}.deb"

# Verifier que dpkg est installé
if ! command -v dpkg-deb &> /dev/null; then
    echo "❌ dpkg-deb n'est pas installé. Installez 'dpkg' et réessayez."
    exit 1
fi

dpkg-deb --build "${PACKAGE_DIR}" "${OUTPUT_DEB}"

# Vérifier le paquet
if dpkg-deb -I "${OUTPUT_DEB}" > /dev/null 2>&1; then
    echo "✅ Paquet créé avec succès!"
    ls -lh "${OUTPUT_DEB}"
    echo ""
    echo "Pour installer le paquet:"
    echo "  sudo dpkg -i ${OUTPUT_DEB}"
    echo ""
    echo "Pour vérifier le paquet:"
    echo "  dpkg -I ${OUTPUT_DEB}"
else
    echo "❌ Erreur lors de la création du paquet"
    exit 1
fi

# Nettoyer
rm -rf "${PACKAGE_DIR}"

echo "✅ Terminé!"
