# DÉMARRAGE RAPIDE - ExeToTux

## En 5 minutes ⚡

### 1. Clone / Navigate
```bash
cd /home/lulyo/Documents/vs_code/ExeToTux
```

### 2. Installer les dépendances
```bash
# Debian/Ubuntu/Linux Mint
sudo apt-get update
sudo apt-get install -y cmake build-essential qt6-base-dev dpkg rpm

# Fedora/RHEL
sudo dnf install -y cmake gcc-c++ qt6-qtbase-devel dpkg rpm-build
```

### 3. Compiler
```bash
chmod +x build.sh
./build.sh
```

### 4. Lancer
```bash
# GUI
./build/exetotux-gui

# CLI
./build/exetotux-cli --help
```

### 5. Créer les paquets (optionnel)
```bash
chmod +x build-deb.sh build-rpm.sh

# .deb
./build-deb.sh

# .rpm  
./build-rpm.sh
```

---

## Alternative: Avec Makefile

```bash
# Build
make build

# Build + Install
make install

# Build + Package everything
make all

# GUI
make run-gui

# Help
make help
```

---

## 🗂️ Structure Fichiers Importants

```
ExeToTux/
├── README.md              ← LIRE EN PREMIER
├── TECHNICAL.md           ← Détails architectures
├── CONTRIBUTING.md        ← Comment contribuer
├── CHANGELOG.md           ← Historique versions
├── QUICKSTART.md          ← Ce fichier
│
├── src/
│   ├── models/            ← PEAnalyzer, ELFGenerator, etc.
│   ├── views/             ← Interface Qt
│   ├── controllers/        ← ConversionController
│   ├── main_gui.cpp       ← Point entrée GUI
│   └── main_cli.cpp       ← Point entrée CLI
│
├── include/               ← Headers .h
│
├── build.sh               ← Script compilation
├── build-deb.sh           ← Création .deb
├── build-rpm.sh           ← Création .rpm
├── Makefile               ← Alternative build
│
└── CMakeLists.txt         ← Config CMake
```

---

## Cas d'Usage

### Cas 1: J'ai un fichier .exe, je veux voir ses métadonnées
```bash
./build/exetotux-cli -a -i ~/monapp.exe
```

### Cas 2: Je veux créer un paquet .deb
```bash
./build/exetotux-cli -i ~/monapp.exe -o ~/Desktop -f deb
```

### Cas 3: Interface graphique interactive
```bash
./build/exetotux-gui
# Puis utiliser les boutons pour sélectionner fichier et options
```

### Cas 4: Créer un paquet pour distribution
```bash
./build-deb.sh
# Génère exetotux_1.0.0_amd64.deb
# À installer: sudo dpkg -i exetotux_1.0.0_amd64.deb
```

---

## ❓ FAQ Rapide

**Q: Pourquoi l'exécutable ne marche pas?**  
R: C'est intentionnel! C'est un wrapper éducatif qui affiche juste les métadonnées.

**Q: Où sont les logs?**  
R: `/tmp/exetotux.log` (GUI) ou `/tmp/exetotux_cli.log` (CLI)

**Q: Erreur CMake Qt6?**  
R: `sudo apt install qt6-base-dev` (ou `sudo dnf install qt6-qtbase-devel`)

**Q: Comment compiler au débugger?**  
R: `make clean-cmake && cmake -DCMAKE_BUILD_TYPE=Debug .. && make`

**Q: Puis-je utiliser sans Qt6?**  
R: Oui! La CLI fonctionne sans interface graphique: `./build/exetotux-cli`

---

## 🔧 Troubleshooting

### Build échoue avec "Qt not found"
```bash
# Installez Qt dev
sudo apt install qt6-base-dev
# Puis retry
./build.sh
```

### "exetotux-gui not found" après ./build.sh
```bash
# Build s'est peut-être arrêté
# Vérifiez les erreurs précédentes
# Réessayez après fix
./build.sh
```

### Fichier .exe non reconnu
```bash
# Vérifiez que c'est un vrai PE
file ~/monapp.exe
# Doit afficher: "PE32+ executable"

# Sinon, c'est un fake EXE
./build/exetotux-cli -a -i ~/monapp.exe
# Vérifiez les erreurs dans le log
```

---

## 📚 Documentation Complète

- [README.md](README.md) - Guide utilisateur complet (50+ pages)
- [TECHNICAL.md](TECHNICAL.md) - Architecture et détails techniques
- [CONTRIBUTING.md](CONTRIBUTING.md) - Guide contribution
- [CHANGELOG.md](CHANGELOG.md) - Historique versions

---

## ⏱️ Temps Approximatifs

| Action | Temps |
|--------|-------|
| Install dépendances | 2-5 min |
| Compilation complète | 3-5 sec |
| Création .deb | 2-3 sec |
| Création .rpm | 3-5 sec |
| Conversion PE → paquet | <5 sec |
| **TOTAL** | **~15 min** |

---

## Supporté sur

✅ Debian 11/12  
✅ Ubuntu 22.04+  
✅ Linux Mint 21+  
✅ Fedora 37+ (avec rpm-build)  
✅ RHEL/CentOS 9+  
✅ Arch Linux  

---

## Next Steps

1. **Lire** [README.md](README.md)
2. **Compiler** avec `./build.sh`
3. **Tester** GUI: `./build/exetotux-gui`
4. **Explorer** le code dans `src/`
5. **Contribuer** via [CONTRIBUTING.md](CONTRIBUTING.md)

---

Besoin d'aide? Vérifiez les logs:
```bash
cat /tmp/exetotux.log
tail -30 /tmp/exetotux_cli.log
```

Prêt? Let's go! 🚀
