# ExeToTux - PE to Linux Package Converter

Un outil expérimental et pédagogique pour convertir les fichiers exécutables Windows (.exe) en paquets Linux installables (.deb ou .rpm).

⚠️ **Avertissement**: L'exécutable final ne sera PAS fonctionnel. Cet outil est conçu à des fins éducatives et expérimentales.

## Caractéristiques

### 🔍 Analyse PE
- Analyse complète du format PE (Portable Executable)
- Extraction des métadonnées (nom, architecture, subsystem)
- Lecture du header DOS et PE
- Énumération des sections

### 🏗️ Architecture Détectée
- Identification automatique: x86 (32-bit), x64 (64-bit), ARM
- Détection du subsystem (GUI, Console, etc.)

### 📦 Génération de Paquets
- **Format .deb** pour Debian/Ubuntu/Linux Mint
- **Format .rpm** pour Fedora/RHEL/CentOS

### 🖥️ Interface
- **GUI** native avec Qt6
- **CLI** puissante avec nombreuses options
- Journalisation complète

### ⚙️ Wrapper ELF
- Génération automatique du wrapper en C
- Compilation en binaire ELF natif
- Affichage des métadonnées PE
- Suggestions d'outils pour exécuter le .exe (Wine, Proton, etc.)

## Requirements

### Build
```bash
# Debian/Ubuntu
sudo apt-get install cmake build-essential qt6-base-dev dpkg rpm

# Fedora/RHEL
sudo dnf install cmake gcc-c++ qt6-qtbase-devel dpkg rpm-build
```

### Runtime
```bash
# GUI
libqt6core6 libqt6gui6 libqt6widgets6

# Outils de packaging
dpkg rpm gcc

# Optionnel (pour exécuter les .exe)
wine winetricks
```

## Build

### 1. Cloner le projet
```bash
cd /home/lulyo/Documents/vs_code/ExeToTux
```

### 2. Compiler l'application
```bash
chmod +x build.sh
./build.sh
```

Cela crée:
- `exetotux-gui` - Version GUI avec Qt
- `exetotux-cli` - Version CLI

### 3. Créer les paquets distribu ables

#### Package .deb
```bash
chmod +x build-deb.sh
./build-deb.sh
```
Génère: `exetotux_1.0.0_amd64.deb`

#### Package .rpm
```bash
chmod +x build-rpm.sh
./build-rpm.sh
```
Génère: `exetotux-1.0.0-1.x86_64.rpm`

## Utilisation

### Mode GUI

```bash
./build/exetotux-gui
```

1. Cliquez sur "Sélectionner EXE" pour choisir un fichier .exe
2. Visualisez les infos PE détectées
3. Choisissez le format de paquet (.deb ou .rpm)
4. Sélectionnez le répertoire de sortie
5. Cliquez "Lancer la Conversion"

### Mode CLI

```bash
./build/exetotux-cli --help
```

#### Conversion simple
```bash
./build/exetotux-cli -i app.exe -o /tmp -f deb
./build/exetotux-cli -i app.exe -o /tmp -f rpm
```

#### Analyser uniquement
```bash
./build/exetotux-cli -a -i app.exe
```

#### Avec log personnalisé
```bash
./build/exetotux-cli -i app.exe -o ./ -f deb -l ./conversion.log -v
```

## Options CLI

```
Usage: exetotux-cli [OPTIONS]

OPTIONS:
  -h, --help              Afficher l'aide
  -i, --input FILE        Chemin vers le .exe (REQUIS)
  -o, --output DIR        Répertoire de sortie (défaut: ./)
  -f, --format FORMAT     deb ou rpm (défaut: deb)
  -a, --analyze           Analyser uniquement le PE
  -l, --log FILE          Fichier de log
  -v, --verbose           Mode verbose
```

## Structure du Projet

```
ExeToTux/
├── include/              # Headers (.h)
│   ├── pe_analyzer.h
│   ├── elf_generator.h
│   ├── package_generator.h
│   ├── logger.h
│   ├── conversion_controller.h
│   └── mainwindow.h
├── src/
│   ├── models/           # Implémentations des modèles
│   ├── views/            # Interfaces Qt
│   ├── controllers/       # Contrôleurs (MVC)
│   ├── main_gui.cpp      # Point d'entrée GUI
│   └── main_cli.cpp      # Point d'entrée CLI
├── ui/                   # Fichiers Qt Designer
├── packaging/            # Fichiers de packaging
├── scripts/              # Scripts utilitaires
├── CMakeLists.txt        # Configuration CMake
├── build.sh              # Build script
├── build-deb.sh          # Script creation .deb
└── build-rpm.sh          # Script creation .rpm
```

## Architecture MVC

### Models (Modèles)
- **PEAnalyzer**: Analyse les fichiers PE
- **ELFGenerator**: Génère les wrappers ELF
- **PackageGenerator**: Crée les paquets .deb/.rpm
- **Logger**: Journalisation centralisée

### Views (Vues)
- **MainWindow**: Interface Qt principale
- Dialogues et widgets various

### Controllers (Contrôleurs)
- **ConversionController**: Orchestration du processus complet

## Flux de Conversion

```
Fichier .exe
    ↓
[PEAnalyzer] → Analyse PE + Extraction métadonnées
    ↓
[ELFGenerator] → Génération wrapper C → Compilation ELF
    ↓
[PackageGenerator] → Création structure paquet
    ↓
[dpkg-deb / rpmbuild] → Construire paquet final
    ↓
Paquet installable (.deb / .rpm)
```

## Exemple de Rapport PE vs ELF

```
═══════════════════════════════════════════════════════════
           RAPPORT DE COMPARAISON PE vs ELF
═══════════════════════════════════════════════════════════

📊 FORMAT PE (Portable Executable)
─────────────────────────────────────────────────────────────
Fichier: myapp.exe
Valide: OUI
Taille: 524288 bytes
Architecture: x86-64 (64-bit)
Subsystem: Windows GUI
Sections: 5
  - .text
  - .data
  - .rsrc
  - .reloc
  - .debug

📦 FORMAT ELF (Executable and Linkable Format)
─────────────────────────────────────────────────────────────
Fichier: myapp-launcher
Type: Linux native executable wrapper
Plateforme: Linux (Debian/Ubuntu, Fedora, etc.)

🔍 ANALYSE COMPARÉE
✓ Wrapper ELF généré
✓ Status exécution: Non-fonctionnel (Intentionnel)
```

## Fichiers Générés dans le Paquet

```
/opt/nom-app/
  ├── app.exe              (fichier original)
  └── launcher             (wrapper ELF compilé)

/usr/bin/
  └── nom-app → /opt/nom-app/launcher

/usr/share/applications/
  └── nom-app.desktop

/usr/share/doc/
  └── exetotux/
```

## Exemple de Wrapper ELF Généré

```c
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#define APP_NAME "myapp"

int show_info() {
    printf("╔════════════════════════════════════════════╗\n");
    printf("║     ExeToTux - PE to Linux Wrapper        ║\n");
    printf("╚════════════════════════════════════════════╝\n\n");
    printf("📦 Application détectée: %s\n", APP_NAME);
    printf("🔧 Architecture: x86-64 (64-bit)\n");
    printf("⚠️  AVERTISSEMENT: Cette application est une exécutable Windows\n");
    printf("    Elle ne peut pas être exécutée nativement sur Linux.\n");
    printf("💡 Pour exécuter, utilisez: wine /opt/myapp/app.exe\n");
    return 0;
}

int main(int argc, char* argv[]) {
    show_info();
    return 1;
}
```

## Options Avancées

### Journalisation
Les logs sont enregistrés dans:
- `/tmp/exetotux.log` (GUI)
- `/tmp/exetotux_cli.log` (CLI)

Le format est: `[YYYY-MM-DD HH:MM:SS] [LEVEL] message`

### Mode Verbose
Affiche les détails de chaque étape du processus.

### Rapport Comparatif
Affiche les différences entre PE et ELF dans l'interface.

## Compilation Manual

Si vous préférez compiler manuellement:

```bash
cd /home/lulyo/Documents/vs_code/ExeToTux
mkdir build && cd build
cmake -DCMAKE_BUILD_TYPE=Release ..
make -j$(nproc)
make install
```

## Installation du Paquet

### Paquet .deb
```bash
sudo dpkg -i exetotux_1.0.0_amd64.deb
sudo apt-get install -f  # Si dépendances manquentes

# Démarrer
exetotux-gui
exetotux-cli --help
```

### Paquet .rpm
```bash
sudo rpm -ivh exetotux-1.0.0-1.x86_64.rpm

# Démarrer
exetotux-gui
exetotux-cli --help
```

## Dépannage

### Qt6 non trouvé lors du build
```bash
sudo apt-get install qt6-base-dev
# ou
sudo dnf install qt6-qtbase-devel
```

### dpkg-deb ou rpmbuild non trouvé
```bash
# Pour .deb
sudo apt-get install dpkg

# Pour .rpm
sudo apt-get install rpm
sudo dnf install rpm-build
```

### Erreur: "Aucun compilateur C trouvé"
```bash
sudo apt-get install build-essential
# ou
sudo dnf install gcc-c++
```

### L'application ne se lance pas
```bash
# Vérifier les logs
tail -f /tmp/exetotux.log

# Mode terminal pour voir les erreurs
exetotux-gui 2>&1 | head -50
```

## Limitations Connues

- ✗ L'exécutable final ne fonctionne pas (c'est intentionnel)
- ✗ Impossible d'extraire les icônes PE actuellement
- ✗ Les dépendances système PE ne sont pas résolues
- ✓ Fonctionne avec tous les architectures PE communes

## Cas d'Usage

### Expérimentation
- Apprendre le format PE
- Comprendre la structure ELF
- Étudier la génération de paquets Linux

### Analyse
- Examiner les métadonnées PE
- Comparer les formats PE vs ELF
- Documentaire l'architecture d'une application

### Éducation
- Enseignement de la sécurité informatique
- Cours sur les formats de fichiers exécutables
- Ateliers de programmation système

## Licences et Attribution

- **ExeToTux**: MIT License
- **Qt6**: LGPL v3
- **dpkg/rpm**: GPL v2+

## Contribution

Les contributions sont bienvenues! Consultez le fichier CONTRIBUTING.md pour plus de détails.

## Support

Pour les problèmes, suggestions ou améliorations:
- Ouvrir une issue sur GitHub
- Consulter la documentation dans `/usr/share/doc/exetotux`
- Vérifier les logs dans `/tmp/exetotux.log`

---

**Développé avec ❤️ par ExeToTux Team**  
Version: 1.0.0 | Date: Février 2025
