#!/bin/bash

# Script pour créer un fichier .exe test
# Ce fichier .exe contient un header PE minimal valide pour tester la conversion

OUTPUT_FILE="${1:-test-program.exe}"

cat > /tmp/test_program.c << 'EOF'
#include <stdio.h>
#include <windows.h>

int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance,
                   LPSTR lpCmdLine, int nShowCmd) {
    MessageBoxA(NULL,
        "ExeToTux Test Program\n"
        "Version 1.0.0\n"
        "Architecture: x64\n\n"
        "This is a test executable for the ExeToTux converter.",
        "ExeToTux Test",
        MB_OK | MB_ICONINFORMATION);
    
    return 0;
}
EOF

echo "[*] Création du fichier .exe test..."

# Essayer avec MinGW d'abord
if command -v x86_64-w64-mingw32-gcc &> /dev/null; then
    echo "    Compilation avec MinGW x86_64..."
    x86_64-w64-mingw32-gcc /tmp/test_program.c -o "$OUTPUT_FILE" -mwindows 2>/dev/null
    if [ $? -eq 0 ]; then
        echo "✓ Fichier créé avec MinGW: $OUTPUT_FILE"
        exit 0
    fi
fi

# Fallback : créer un stub PE minimal valide
echo "    Création d'un stub PE minimal..."

python3 << 'PYTHON'
import struct
import sys

output_file = sys.argv[1]

# DOS Header (64 bytes)
dos_header = bytearray(64)
dos_header[0:2] = b'MZ'  # Signature
dos_header[40:44] = struct.pack('<I', 64)  # PE header offset

# DOS stub
dos_stub = b"This program cannot be run in DOS mode.\r\r\n$"

# PE Signature
pe_sig = b'PE\x00\x00'

# COFF Header (20 bytes)
coff_header = bytearray(20)
coff_header[0:2] = struct.pack('<H', 0x8664)    # Machine (x64)
coff_header[2:4] = struct.pack('<H', 3)         # Number of sections
coff_header[4:8] = struct.pack('<I', 0)         # TimeDateStamp
coff_header[8:12] = struct.pack('<I', 0)        # PointerToSymbolTable
coff_header[12:16] = struct.pack('<I', 0)       # NumberOfSymbols
coff_header[16:18] = struct.pack('<H', 240)     # SizeOfOptionalHeader
coff_header[18:20] = struct.pack('<H', 0x022F)  # Characteristics

# Optional Header (240 bytes) - PE32+
optional_header = bytearray(240)
optional_header[0] = 0x0B  # Magic (PE32+)
optional_header[1] = 0x02
optional_header[28:32] = struct.pack('<I', 4096)   # SizeOfHeaders
optional_header[32:36] = struct.pack('<I', 512)    # FileAlignment
optional_header[36:40] = struct.pack('<I', 4096)   # SectionAlignment

# Section Headers (40 bytes each, 3 sections)
sections = [
    (b'.text\x00\x00\x00', 0x60000020),
    (b'.data\x00\x00\x00', 0xC0000040),
    (b'.rsrc\x00\x00\x00', 0x40000040),
]

section_headers = bytearray()
for name, flags in sections:
    sh = bytearray(40)
    sh[0:8] = name
    sh[8:12] = struct.pack('<I', 512)   # VirtualSize
    sh[12:16] = struct.pack('<I', 4096) # VirtualAddress
    sh[16:20] = struct.pack('<I', 512)  # SizeOfRawData
    sh[20:24] = struct.pack('<I', 512)  # PointerToRawData
    sh[36:40] = struct.pack('<I', flags)  # Characteristics
    section_headers.extend(sh)

# Write file
with open(output_file, 'wb') as f:
    f.write(dos_header)
    f.write(dos_stub)
    f.write(b'\x00' * (64 - len(dos_stub)))
    f.write(pe_sig)
    f.write(coff_header)
    f.write(optional_header)
    f.write(section_headers)
    f.write(b'\x00' * (512 - f.tell()))  # Padding to 512

print(f"✓ Stub PE créé: {output_file}")
PYTHON "$OUTPUT_FILE"
