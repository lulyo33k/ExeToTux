#!/usr/bin/env bash

# Script de création du paquet .rpm pour ExeToTux

set -e

echo "════════════════════════════════════════════"
echo "   ExeToTux - RPM Package Builder"
echo "════════════════════════════════════════════"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
BUILD_DIR="${SCRIPT_DIR}/build"
RPM_DIR="${SCRIPT_DIR}/rpmbuild"
VERSION="1.0.0"
RELEASE="1"

# Vérifier que rpmbuild est installé
if ! command -v rpmbuild &> /dev/null; then
    echo "❌ rpmbuild n'est pas installé."
    echo "   Sur Fedora/RHEL: sudo dnf install rpm-build"
    echo "   Sur Debian/Ubuntu: sudo apt install rpm"
    exit 1
fi

# Créer la structure RPM
echo "📁 Création de la structure RPM..."
rm -rf "${RPM_DIR}"
mkdir -p "${RPM_DIR}"/{SOURCES,SPECS,BUILD,RPMS,SRPMS}

# Vérifier les exécutables
if [ ! -f "${BUILD_DIR}/exetotux-gui" ] || [ ! -f "${BUILD_DIR}/exetotux-cli" ]; then
    echo "❌ Les exécutables n'ont pas été trouvés. Compilez d'abord avec ./build.sh"
    exit 1
fi

# Créer l'archive source
echo "📦 Création de l'archive source..."
SOURCE_DIR="${RPM_DIR}/exetotux-${VERSION}"
TARBALL="${RPM_DIR}/SOURCES/exetotux-${VERSION}.tar.gz"

mkdir -p "${SOURCE_DIR}"/{bin,share/applications,share/doc}

cp "${BUILD_DIR}/exetotux-gui" "${SOURCE_DIR}/bin/"
cp "${BUILD_DIR}/exetotux-cli" "${SOURCE_DIR}/bin/"
cp "${SCRIPT_DIR}/packaging/exetotux.desktop" "${SOURCE_DIR}/share/applications/"

chmod 755 "${SOURCE_DIR}/bin/exetotux-gui"
chmod 755 "${SOURCE_DIR}/bin/exetotux-cli"

cd "${RPM_DIR}"
tar -czf "${TARBALL}" exetotux-${VERSION}/
cd "${SCRIPT_DIR}"

echo "📝 Création du spec file..."
cat > "${RPM_DIR}/SPECS/exetotux.spec" <<'EOF'
Name:           exetotux
Version:        1.0.0
Release:        1%{?dist}
Summary:        PE to Linux Package Converter
License:        MIT
URL:            https://github.com/exetotux/exetotux
Source0:        exetotux-%{version}.tar.gz

BuildRequires:  gcc-c++ make cmake qt6-qtbase-devel
Requires:       libqt6core6 libqt6gui6 libqt6widgets6 dpkg rpm gcc

%description
ExeToTux is an experimental tool for converting Windows PE executables
into installable Linux packages (.deb, .rpm).

Features:
 - Analyze PE file format
 - Extract metadata (architecture, subsystem)  
 - Generate ELF wrapper
 - Create installable packages

Warning: The resulting executable will not be functional.
This is an educational and experimental tool.

%prep
%setup -q

%build
# Pre-compiled binaries, nothing to build

%install
mkdir -p %{buildroot}/usr/bin
mkdir -p %{buildroot}/usr/share/applications
mkdir -p %{buildroot}/usr/share/doc/%{name}

cp bin/exetotux-gui %{buildroot}/usr/bin/
cp bin/exetotux-cli %{buildroot}/usr/bin/
chmod 755 %{buildroot}/usr/bin/exetotux-*
ln -sf exetotux-gui %{buildroot}/usr/bin/exetotux

cp share/applications/exetotux.desktop %{buildroot}/usr/share/applications/

cat > %{buildroot}/usr/share/doc/%{name}/README <<'EOFREAD'
ExeToTux - PE to Linux Package Converter
========================================

Convert Windows .exe files to installable Linux packages (.deb, .rpm).

Usage:
  GUI: exetotux-gui
  CLI: exetotux-cli --help

Features:
  - PE file analysis
  - Metadata extraction
  - ELF wrapper generation
  - Package creation

Note: This is an experimental and educational tool.
EOFREAD

%files
/usr/bin/exetotux
/usr/bin/exetotux-gui
/usr/bin/exetotux-cli
/usr/share/applications/exetotux.desktop
/usr/share/doc/%{name}/README

%post
/usr/bin/exetotux-gui --version > /dev/null 2>&1 || true

%changelog
* Wed Feb 26 2025 ExeToTux Team <dev@exetotux.local> - 1.0.0-1
- Initial release
- PE analysis functionality
- DEB and RPM package generation
- Qt GUI and CLI interfaces
- ELF wrapper generation

EOF

# Compiler le RPM
echo ""
echo "🔨 Construction du paquet RPM..."

rpmbuild -bb \
  --define "_topdir ${RPM_DIR}" \
  --define "_builddir %{_topdir}/BUILD" \
  --define "_rpmdir %{_topdir}/RPMS" \
  --define "_srcrpmdir %{_topdir}/SRPMS" \
  "${RPM_DIR}/SPECS/exetotux.spec"

# Trouver et copier le RPM généré
OUTPUT_RPM=$(find "${RPM_DIR}/RPMS" -name "exetotux-*.rpm" 2>/dev/null | head -1)

if [ -n "${OUTPUT_RPM}" ]; then
    cp "${OUTPUT_RPM}" "${SCRIPT_DIR}/"
    OUTPUT_RPM="${SCRIPT_DIR}/$(basename "${OUTPUT_RPM}")"
    
    echo "✅ Paquet créé avec succès!"
    ls -lh "${OUTPUT_RPM}"
    echo ""
    echo "Pour installer le paquet:"
    echo "  sudo rpm -ivh ${OUTPUT_RPM}"
    echo ""
    echo "Pour vérifier le paquet:"
    echo "  rpm -qpi ${OUTPUT_RPM}"
else
    echo "❌ Erreur lors de la création du paquet RPM"
    exit 1
fi

# Nettoyer
rm -rf "${RPM_DIR}"

echo "✅ Terminé!"
