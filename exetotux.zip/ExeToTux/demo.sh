#!/bin/bash

# Script de démonstration des fonctionnalités d'ExeToTux
# Teste la conversion EXE → DEB/RPM et l'inverse

echo "════════════════════════════════════════════"
echo "  ExeToTux - Démonstration Complète"
echo "════════════════════════════════════════════"
echo ""

PROJECT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CLI_BIN="$PROJECT_DIR/install/bin/exetotux-cli"
SAMPLE_EXE="$PROJECT_DIR/sample-program.exe"
OUTPUT_DIR="/tmp/exetotux-demo"

# Créer le répertoire de sortie
mkdir -p "$OUTPUT_DIR"
cd "$OUTPUT_DIR"

echo "📁 Répertoire de travail: $OUTPUT_DIR"
echo ""

# Test 1 : Vérifier le .exe test
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 1: Analyse du fichier .exe test"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "$SAMPLE_EXE" ]; then
    echo "✓ Fichier trouvé: $SAMPLE_EXE"
    file "$SAMPLE_EXE"
    echo ""
    
    # Analyser le .exe
    echo "📋 Analyse du fichier PE:"
    $CLI_BIN --input "$SAMPLE_EXE" 2>/dev/null | head -20
    echo ""
else
    echo "✗ Fichier .exe test non trouvé!"
    exit 1
fi

# Test 2 : Créer un paquet DEB
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 2: Création d'un paquet DEB"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

$CLI_BIN --input "$SAMPLE_EXE" -f deb -o test-program.deb
if [ -f "test-program.deb" ]; then
    echo "✓ Paquet créé: test-program.deb"
    ls -lh test-program.deb
    echo ""
else
    echo "✗ Échec de création du paquet DEB"
    exit 1
fi

# Test 3 : Créer un paquet RPM
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 3: Création d'un paquet RPM"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

$CLI_BIN --input "$SAMPLE_EXE" -f rpm -o test-program.rpm
if [ -f "test-program.rpm" ]; then
    echo "✓ Paquet créé: test-program.rpm"
    ls -lh test-program.rpm
    echo ""
else
    echo "⚠️ RPM non créé (système non compatible?)"
    echo ""
fi

# Test 4 : Conversion inverse DEB → EXE
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "Test 4: Conversion inverse (DEB → EXE)"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

if [ -f "test-program.deb" ]; then
    echo "🔄 Création du stub Windows depuis test-program.deb..."
    
    # Note: Cette fonctionnalité requiert l'intégration dans le CLI
    # Pour l'instant, on affiche un message d'information
    echo "📝 Fonctionnalité inverse disponible via la classe ReverseConverter"
    echo "   Code exemple:"
    echo "   ```cpp"
    echo "   ReverseConverter converter;"
    echo "   converter.createWindowsStub(\"test-program.deb\", \"test-program.exe\");"
    echo "   ```"
    echo ""
fi

# Résumé
echo "════════════════════════════════════════════"
echo "  ✅ Démonstration Complétée"
echo "════════════════════════════════════════════"
echo ""
echo "Fichiers générés dans: $OUTPUT_DIR"
ls -lh "$OUTPUT_DIR"
echo ""
echo "📚 Documentation complète:"
echo "   - START_HERE.md"
echo "   - QUICKSTART.md"
echo "   - REVERSE-CONVERSION.md"
echo ""
