# ExeToTux - Documentation Index & Navigation Guide

Bienvenue dans la documentation **ExeToTux v1.0.0** !

> 🎯 **PREMIER FICHIER À LIRE**: [START_HERE.md](START_HERE.md)

---

## 📚 GUIDE DE NAVIGATION

### 🚀 Je veux démarrer IMMÉDIATEMENT
**👉 COMMENCE ICI: [QUICKSTART.md](QUICKSTART.md)**
- Guide 5 minutes
- Commandes essentielles  
- FAQ rapide
- Démarrage garantis

### 📖 Je veux comprendre le projet complètement
**Lis dans cet ordre:**
1. [START_HERE.md](START_HERE.md) - Vue d'ensemble générale
2. [README.md](README.md) - Guide utilisateur complet
3. [TECHNICAL.md](TECHNICAL.md) - Architecture et détails implémentation

### 🛠️ Je veux développer/modifier le code
**Le parcours développeur:**
1. [TECHNICAL.md](TECHNICAL.md) - Comprendre l'architecture
2. [CONTRIBUTING.md](CONTRIBUTING.md) - Standards et processus
3. `src/` et `include/` - Explorer le code commenté

### 🐛 J'ai une erreur de build
**Troubleshooting rapide:**
- [README.md - Dépannage](README.md#dépannage)
- [QUICKSTART.md - FAQ](QUICKSTART.md#-faq-rapide)
- Check `/tmp/exetotux*.log` files

### 📦 Je veux packager l'application
**Guide packaging:**
1. [README.md - Installation du Paquet](README.md#installation-du-paquet)
2. [build-deb.sh](build-deb.sh) - Script création .deb
3. [build-rpm.sh](build-rpm.sh) - Script création .rpm

---

## 📋 STRUCTURE DE LA DOCUMENTATION

```
ExeToTux/
│
├── 📍 POINT D'ENTRÉE
│   ├── START_HERE.md         ⭐ LIS MOI EN PREMIER!
│   └── QUICKSTART.md          Démarrage 5 minutes
│
├── 📚 DOCUMENTATION UTILISATEUR
│   ├── README.md              Guide complet (300+ lignes)
│   │   ├── Caractéristiques
│   │   ├── Installation
│   │   ├── Utilisation
│   │   ├── Dépannage
│   │   └── FAQ
│   │
│   ├── TECHNICAL.md           Détails techniques 
│   │   ├── Architecture MVC
│   │   ├── Format PE expliqué
│   │   ├── Format ELF expliqué
│   │   ├── Flux conversion
│   │   └── Optimisations
│   │
│   └── CHANGELOG.md           Historique versions
│       ├── v1.0.0 features
│       ├── Changelog détaillé
│       └── Roadmap futur
│
├── 👥 GUIDE CONTRIBUTION
│   └── CONTRIBUTING.md        Code de contribution
│       ├── Standards coding
│       ├── Processus PR
│       ├── Guide review
│       └── Community guidelines
│
├── 🏗️  FICHIERS DE BUILD
│   ├── CMakeLists.txt         Configuration CMAKE
│   ├── Makefile               Targets make
│   ├── build.sh               Script build simple
│   ├── build-deb.sh           Création .deb
│   ├── build-rpm.sh           Création .rpm
│   └── build.conf.sh          Configuration paramètres
│
├── 📂 CODE SOURCE
│   ├── include/               Headers (.h)
│   └── src/                   Implémentations (.cpp)
│       ├── models/            Business logic
│       ├── views/             Interfaces Qt
│       ├── controllers/        Orchestration
│       ├── main_gui.cpp        Point entrée GUI
│       └── main_cli.cpp        Point entrée CLI
│
├── 🧪 TESTING & DEBUG
│   ├── test.sh                Test rapide
│   └── .gitignore             Git configurations
│
└── 📝 INDEX & INVENTORY
    ├── INDEX.md               Ce fichier
    └── generate-inventory.sh  Générateur inventory
```

---

## 🎯 QUELLE DOCUMENTATION POUR QUEL BESOIN?

| Besoin | Fichier | Temps |
|--------|---------|-------|
| Démarrer rapidement | [QUICKSTART.md](QUICKSTART.md) | 5 min |
| Comprendre projet | [START_HERE.md](START_HERE.md) | 10 min |
| Mode d'emploi complet | [README.md](README.md) | 30 min |
| Architecture système | [TECHNICAL.md](TECHNICAL.md) | 45 min |
| Code source | /src et /include | Variable |
| Contribuer du code | [CONTRIBUTING.md](CONTRIBUTING.md) | 20 min |
| Nouvelle version | [CHANGELOG.md](CHANGELOG.md) | 5 min |
| Build alternatives | [Makefile](Makefile) | 2 min |

---

## 🔍 RECHERCHER RAPIDEMENT

### Par Topic
- **Analyse PE** → [TECHNICAL.md - Format PE](TECHNICAL.md#format-pe---détails-techniques)
- **Génération ELF** → [TECHNICAL.md - Format ELF](TECHNICAL.md#format-elf---détails-techniques)
- **Erreurs build** → [README.md - Dépannage](README.md#dépannage)
- **CLI usage** → [README.md - Mode CLI](README.md#mode-cli)
- **GUI screenshots** → [README.md - Interface GUI](README.md#mode-gui)

### Par Fichiers Source
- **PE Analyzer** → `include/pe_analyzer.h` + `src/models/pe_analyzer.cpp`
- **ELF Generator** → `include/elf_generator.h` + `src/models/elf_generator.cpp`
- **Package Generator** → `include/package_generator.h` + `src/models/package_generator.cpp`
- **Logger** → `include/logger.h` + `src/models/logger.cpp`
- **Main Window (Qt)** → `include/mainwindow.h` + `src/views/mainwindow.cpp`
- **CLI App** → `src/main_cli.cpp`
- **GUI App** → `src/main_gui.cpp`

### Par Cas d'Usage
- **Analyser un fichier PE** → [QUICKSTART.md - Cas 1](QUICKSTART.md#cas-dusage)
- **Créer un paquet .deb** → [QUICKSTART.md - Cas 2](QUICKSTART.md#cas-dusage)
- **Utiliser GUI** → [README.md - Mode GUI](README.md#mode-gui)
- **Contribuer code** → [CONTRIBUTING.md](CONTRIBUTING.md)

---

## ⚡ COMMANDES ESSENTIELLES (Copier-Coller)

```bash
# Build
cd /home/lulyo/Documents/vs_code/ExeToTux
./build.sh

# Run GUI
./build/exetotux-gui

# Run CLI
./build/exetotux-cli --help

# Analyser fichier
./build/exetotux-cli -a -i ~/app.exe

# Créer .deb
./build-deb.sh

# Voir logs
tail -f /tmp/exetotux.log
```

---

## 📖 LECTURE RECOMMANDÉE

### Pour Utilisateurs
1. [QUICKSTART.md](QUICKSTART.md) - 5 min
2. [README.md](README.md) - 30 min
3. [README.md - FAQ](README.md#faq) - 5 min

### Pour Développeurs  
1. [START_HERE.md](START_HERE.md) - 10 min
2. [TECHNICAL.md](TECHNICAL.md) - 45 min
3. [CONTRIBUTING.md](CONTRIBUTING.md) - 20 min
4. Explorerdirectoires `/src` et `/include`

### Pour Contributeurs
1. [CONTRIBUTING.md](CONTRIBUTING.md) - 20 min
2. [TECHNICAL.md](TECHNICAL.md) - Architecture
3. Git best practices externales
4. Code review guidelines

---

## 🎓 APPRENTISSAGE PROGRESSIF

**Niveau 1: Utilisateur**
- Installer dépendances
- Compiler l'app
- Utiliser GUI ou CLI
- Créer paquets

**Niveau 2: Explorateur**
- Lire le code source
- Comprendre l'architecture
- Analyser le flux conversion
- Étudier les patterns utilisés

**Niveau 3: Contributeur**
- Patcher le code
- Soumettre PRs
- Suivre standards coding
- Reviewer du code d'autres

**Niveau 4: Mainteneur**
- Gérer les releases
- Planifier road map
- Réviser architecture majeure
- Décisions design

---

## 📚 RESSOURCES EXTERNES

### C++17 & Modern C++
- cppreference.com - C++ Standard Reference
- isocpp.org - C++ standards committee

### Qt6 Framework
- qt.io/documentation - Official Qt docs
- qt.io/tutorials - Qt tutorials

### Linux Packaging
- debian.org/doc - Debian Policy Manual
- rpm.org - RPM Package Management
- wiki.debian.org - Debian packaging

### PE Format
- microsoft.com - PE Format Specification
- en.wikipedia.org - Windows Portable Executable

### ELF Format
- en.wikipedia.org/wiki/Executable_and_Linkable_Format
- man.archlinux.org - ELF man pages

---

## 🔗 LIENS DIRECTS

### Documentation Locale
- [Démarrer](START_HERE.md)
- [Quick start](QUICKSTART.md)
- [Guide complet](README.md)
- [Technique](TECHNICAL.md)
- [Contribuer](CONTRIBUTING.md)
- [Historique versions](CHANGELOG.md)

### Code Source
- [Include headers](include/)
- [Source files](src/)
- [Models](src/models/)
- [Views](src/views/)
- [Controllers](src/controllers/)

### Configuration & Build
- [CMakeLists.txt](CMakeLists.txt)
- [Makefile](Makefile)
- [build.sh](build.sh)
- [build-deb.sh](build-deb.sh)
- [build-rpm.sh](build-rpm.sh)

---

## ❓ QUESTIONS FRÉQUENTES

**Q: Par où commencer?**  
R: Lire [START_HERE.md](START_HERE.md)

**Q: Comment compiler?**  
R: Lire [QUICKSTART.md](QUICKSTART.md)

**Q: Où sont les logs?**  
R: `/tmp/exetotux.log` (GUI) ou `/tmp/exetotux_cli.log` (CLI)

**Q: Comment contribuer?**  
R: Lire [CONTRIBUTING.md](CONTRIBUTING.md)

**Q: C'est prêt pour production?**  
R: Oui, version 1.0.0 Production Ready RC

---

## 📞 SUPPORT

### Ressources Locales
- Logs: `/tmp/exetotux*.log`
- Build output: `./build/CMakeFiles/`
- Source code: Self-documented

### Documentation Locale
- README.md
- TECHNICAL.md
- CONTRIBUTING.md

### Débogage
```bash
# Voir les errors détaillées
tail -50 /tmp/exetotux_cli.log
tail -50 /tmp/exetotux.log

# Recompiler avec debug
cmake -DCMAKE_BUILD_TYPE=Debug ..
make
```

---

## 🎓 NOTATIONS & CONVENTIONS

### Dans la Documentation
- 🚀 = Important à faire
- ✅ = Complété/Succès
- ❌ = Erreur/Attention
- 📝 = Note/Information
- 💡 = Conseil/Tip
- ⚠️ = Avertissement

### Dans le Code
- `// ...` = Commentaires explications
- `/** ... */` = Doxygen doc comments
- `#define` = Constantes et macros
- `constexpr` = Constantes compile-time

---

## 🔄 MISES À JOUR DOCUMENTATION

Cette documentation est à jour pour ExeToTux v1.0.0 (26 février 2025).

Pour vérifier les mises à jour:
```bash
cat CHANGELOG.md | head -20
```

---

## 📄 LICENSE

- ExeToTux: MIT License
- Qt6: LGPL v3
- dpkg/rpm: GPL v2+

Voir les header fichiers source pour plus de détails.

---

## Navigation Rapide

```
START_HERE.md ─→ Comprendre le projet
     ↓
QUICKSTART.md ─→ Démarrer immédiatement
     ↓
README.md ────→ Documentation complète
     ↓
TECHNICAL.md ─→ Détails implémentation
     ↓
src/ include/ ►→ Explorer le code
     ↓
CONTRIBUTING ►→ Contribuer du code
```

---

**Version**: 1.0.0  
**Date**: 26 février 2025  
**Status**: Production Ready  
**Prét?** → Commence par [START_HERE.md](START_HERE.md) 🚀
