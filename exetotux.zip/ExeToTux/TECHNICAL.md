# ExeToTux - Architecture et Design

## Vue d'ensemble

ExeToTux est une application C++/Qt moderne suivant le pattern MVC (Model-View-Controller). Elle se compose de quatre couches principales:

```
┌─────────────────────────────────────────┐
│         Interface Utilisateur             │
│  ┌──────────────────────────────────┐   │
│  │  MainWindow (Qt Widgets)         │   │
│  │  - Sélection fichier             │   │
│  │  - Affichage détails PE          │   │
│  │  - Barre progression             │   │
│  └──────────────────────────────────┘   │
└─────────────────────────────────────────┘
         ↓ Signaux Qt / Callbacks
┌─────────────────────────────────────────┐
│           Contrôleurs (MVC)              │
│  ┌──────────────────────────────────┐   │
│  │  ConversionController            │   │
│  │  - Orchestration du flux         │   │
│  │  - Gestion des erreurs           │   │
│  │  - Callbacks de progression      │   │
│  └──────────────────────────────────┘   │
└─────────────────────────────────────────┘
         ↓ Appels de méthodes
┌─────────────────────────────────────────┐
│          Modèles (Business Logic)        │
│  ┌──────────────────────────────────┐   │
│  │  PEAnalyzer                      │   │
│  │  - Analyse format PE             │   │
│  │  - Extraction métadonnées        │   │
│  ├──────────────────────────────────┤   │
│  │  ELFGenerator                    │   │
│  │  - Génération code C             │   │
│  │  - Compilation GCC              │   │
│  ├──────────────────────────────────┤   │
│  │  PackageGenerator                │   │
│  │  - Structure paquet              │   │
│  │  - dpkg-deb / rpmbuild           │   │
│  ├──────────────────────────────────┤   │
│  │  Logger                          │   │
│  │  - Journalisation centralisée    │   │
│  └──────────────────────────────────┘   │
└─────────────────────────────────────────┘
         ↓ Appels système
┌─────────────────────────────────────────┐
│      Outils système et Bibliothèques     │
│  - système de fichiers (C++ STL)        │  
│  - compilation (GCC/Clang)              │  
│  - packaging (dpkg-deb, rpmbuild)       │  
└─────────────────────────────────────────┘
```

## Composants Détaillés

### 1. PEAnalyzer (src/models/pe_analyzer.cpp)

Analyse les fichiers PE (Portable Executable) Windows.

**Responsabilités**:
- Lire et valider le header DOS (signature "MZ")
- Lire et valider le header PE (signature "PE\0\0")
- Extraire les métadonnées (architecture, subsystem)
- Énumérer les sections binaires
- Détecter les ressources (icônes, chaînes)

**Structures principales**:
```cpp
struct PEMetadata {
    std::string filename;
    std::string appName;        // Nom application extrait
    std::string architecture;   // x86, x64, arm
    uint32_t machineType;       // Code machine
    uint32_t subsystem;         // GUI, Console, etc.
    size_t fileSize;            // Taille du fichier
    bool isValid;               // Validité du PE
    std::vector<std::string> sections;  // Sections PE
};
```

**Flux d'analyse**:
```
Fichier .exe
    ↓
Lire DOS Header (bytes 0-63)
    ↓ Vérifier signature "MZ" (0x5A4D)
    ↓
Lire PE offset (byte 0x3C)
    ↓
Aller au Header PE
    ↓ Vérifier signature "PE\0\0" (0x00004500)
    ↓
Lire COFF Header
    ↓ Machine Type (i386, x64, ARM)
    ↓
Lire Optional Header  
    ↓ Subsystem (GUI, Console)
    ↓
Énumérer Sections
    ↓
Retourner PEMetadata
```

**Valeurs machine types**:
- `0x014c`: Intel i386 (x86 32-bit)
- `0x8664`: AMD x86-64 (x64 64-bit)
- `0x01c0`: ARM

**Subsystem values**:
- `0`: Unknown
- `2`: Windows GUI
- `3`: Windows Console
- `5`: OS/2 Console
- `7`: POSIX Console
- `10`: EFI Boot Service

### 2. ELFGenerator (src/models/elf_generator.cpp)

Génère un wrapper ELF minimal en C qui affiche les métadonnées PE.

**Responsabilités**:
- Générer le code C source du wrapper
- Compiler le C en binaire ELF 64-bit
- Créer un exécutable natif Linux non-fonctionnel

**Code C généré**:
```c
#include <stdio.h>
#include <stdlib.h>

/* Affiche les métadonnées PE */
int show_info() {
    printf("Application: %s\n", APP_NAME);
    printf("Architecture: x86-64\n");
    printf("WARNING: This is a Windows executable!\n");
    return 0;
}

int main(int argc, char* argv[]) {
    show_info();
    return 1;  /* Non-fonctionnel intentionnellement */
}
```

**Processus de compilation**:
```bash
gcc -O2 -static-libgcc -s launcher.c -o launcher
chmod 755 launcher
```

Flags utilisés:
- `-O2`: Optimisation niveau 2
- `-static-libgcc`: Lier statiquement la libc
- `-s`: Stripper les symboles de debug
- `chmod 755`: Rendre exécutable

### 3. PackageGenerator (src/models/package_generator.cpp)

Crée les paquets Linux (.deb et .rpm).

**Processus .deb**:
```
PackageDir/
├── opt/nom-app/
│   ├── app.exe (fichier original)
│   └── launcher (wrapper ELF)
├── usr/bin/
│   └── nom-app → /opt/nom-app/launcher (symlink)
├── usr/share/applications/
│   └── nom-app.desktop
└── DEBIAN/
    ├── control (métadonnées paquet)
    ├── postinst (script post-installation)
    ├── prerm (script pré-suppression)
    └── conffiles (optionnel)

↓ dpkg-deb --build
→ nom-app_1.0.0_amd64.deb
```

**Contenu du fichier control**:
```
Package: nom-app
Version: 1.0.0
Architecture: amd64
Maintainer: ExeToTux <auto@exetotux.local>
Installed-Size: 1024
Description: Windows executable wrapper
```

**Processus .rpm**:
```
RPM Build/
├── SOURCES/
│   └── nom-app-1.0.0.tar.gz
├── SPECS/
│   └── nom-app.spec
├── BUILD/
├── RPMS/
├── SRPMS/

↓ rpmbuild -bb
→ nom-app-1.0.0-1.x86_64.rpm
```

**Structure spec file**:
- `%description`: Métadonnées du paquet
- `%prep`: Préparation (décompression)
- `%build`: Compilation (vide ici)
- `%install`: Installation dans buildroot
- `%files`: Fichiers à inclure
- `%post`: Script après installation
- `%changelog`: Historique versions

### 4. ConversionController (src/controllers/conversion_controller.cpp)

Orchestre le processus complet de conversion.

**Flux principal**:
```
convert(exePath, outputDir, format)
    ↓
[1] Analyser PE → PEAnalyzer::analyzeFile()
    ↓ 0% → 25%
    ↓
[2] Générer wrapper → ELFGenerator::generateWrapperC()
    ↓ 25% → 50%
    ↓
[3] Compiler wrapper → ELFGenerator::compileCToELF()
    ↓ 50% → 70%
    ↓
[4] Créer paquet → PackageGenerator::generatePackage()
    ↓ 70% → 100%
    ↓
[5] Retourner résultat (succès/erreur)
```

**Gestion des erreurs**:
- Chaque étape stocke les erreurs
- Callbacks de progression informent l'UI
- Log complet dans Logger

### 5. Logger (src/models/logger.cpp)

Singleton pour journalisation centralisée.

**Format des logs**:
```
[2025-02-26 10:30:45] [INFO] Analyse du fichier PE: app.exe
[2025-02-26 10:30:46] [DEBUG] Signature PE valide
[2025-02-26 10:30:47] [WARNING] Architecture détectée: x86-64
[2025-02-26 10:30:48] [ERROR] Erreur lors de la compilation
```

**Niveaux**:
- `DEBUG`: Informations détaillées
- `INFO`: Informations générales
- `WARNING`: Avertissements
- `ERROR`: Erreurs
- `CRITICAL`: Erreurs critiques

### 6. MainWindow (src/views/mainwindow.cpp)

Interface Qt6 native.

**Widgets principaux**:
- `QLineEdit`: Chemins fichier/dossier
- `QComboBox`: Sélection format (.deb/.rpm)
- `QProgressBar`: Barre de progression
- `QTextEdit`: Affichage infos PE
- `QPushButton`: Actions principales
- `QTableWidget`: Détails sections (optionnel)

**Signaux/Slots**:
```cpp
selectExeBtn → onSelectExeFile()
selectOutputBtn → onSelectOutputDir()
convertBtn → onConvert() [thread séparé via std::thread]
detailedInfoBtn → onShowDetailedInfo()
```

**Actualisation UI depuis thread**:
```cpp
std::thread(..., [this]() {
    // Travail sur thread
    QMetaObject::invokeMethod(this, [this]() {
        // Mise à jour UI sur thread principal
    });
}).detach();
```

## Format PE - Détails Techniques

### Structure du header PE

```
DOS Header (64 bytes)
├── e_magic (0x5A4D = "MZ")
├── e_cblp, e_cp, ...
└── e_lfanew (offset au PE header) → 0x3C

DOS Stub (variable)

PE Header
├── PE Signature (0x4550 = "PE\0\0")
├── COFF Header (20 bytes)
│   ├── Machine (Intel, AMD64, ARM, etc.)
│   ├── NumberOfSections
│   ├── PointerToSymbolTable
│   └── NumberOfSymbols
├── Optional Header (224/240 bytes)
│   ├── Magic (0x10b=32-bit, 0x20b=64-bit)
│   ├── Subsystem (GUI, Console, Riginature)
│   └── ...
└── Section Headers (40 bytes chacun × NumberOfSections)
    ├── Name (.text, .data, .rsrc, .reloc, .debug)
    ├── VirtualSize
    ├── VirtualAddress
    ├── SizeOfRawData
    └── PointerToRawData

Section Data
├── .text (code exécutable)
├── .data (données initialisées)
├── .rsrc (ressources: icônes, chaînes, dialogs)
├── .reloc (relocations)
└── .debug (symboles debug optionnels)
```

### Offset clés

```
0x00        DOS Header
0x3C        Offset PE Header
0x3C + val  PE Signature "PE\0\0"
+0x04       Machine Type (COFF Header)
+0x06       Number of Sections
+0x18       Optional Header Size
+0x44       Subsystem (Optional Header)
```

## Format ELF - Détails Techniques

### Structure du header ELF 64-bit

```
ELF Header (64 bytes)
├── e_ident[EI_MAG0..3] (0x7F 'E' 'L' 'F')
├── e_type (ET_EXEC=2 pour exécutable)
├── e_machine (EM_X86_64=62 pour x86-64)
├── e_version (1)
├── e_entry (point d'entrée, ~0x400000)
├── e_phoff (offset programme headers)
├── e_shoff (offset section headers)
├── e_flags (flags spécifiques arch)
├── e_ehsize (taille du ELF header)
├── e_phentsize (taille prog header)
├── e_phnum (nombre prog headers)
├── e_shentsize (taille section header)
├── e_shnum (nombre sections)
└── e_shstrndx (section header string table)

Program Headers (décrit segments pour chargement)
├── PT_LOAD (segments à charger)
├── PT_DYNAMIC (infos dynamiques)
├── PT_INTERP (interpréteur /lib64/ld-linux-x86-64.so.2)
└── ...

Section Headers (décrit sections pour linking)
├── .text (code)
├── .data (données)
├── .rodata (constantes)
├── .bss (données non-initialisées)
├── .symtab (table symboles)
├── .strtab (table chaînes)
└── ...

Segments Data
├── Interpréteur dynamique
├── .text section
├── .data section
├── .rodata section
└── .bss section
```

## Compilation du Wrapper

### Dépendances

```
launcher.c
├── stdio.h (printf)
├── stdlib.h (exit)
└── unistd.h (getopt optionnel)

↓
gcc -O2 -static-libgcc -s launcher.c -o launcher

↓
ELF 64-bit LSB executable, x86-64, dynamically linked
```

### Taille binaire

Wrapper simple sans dépendances:
- ~20-50 KB (avec gcc statique)
- ~10-20 KB (avec stripping)

## Dépendances système

### Build-time
- cmake >= 3.16
- gcc ou clang
- qt6-base-dev
- dpkg
- rpm-build

### Runtime
- qt6-base libraries
- glibc
- dpkg (pour créer .deb)
- rpm (pour créer .rpm)
- gcc (optionnel, pour recompiler wrapper)

## Optimisations possibles

1. **Ressources embarquées**: Qt Resource System (.qrc)
2. **Dépendances parallèles**: Compilation async
3. **Cache**: Mémoriser les analyses PE
4. **Compression**: Compresser les archives source
5. **Signature**: Signer les paquets GPG

## Limitations et Considérations

### Limitations actuelles
- No icon extraction from PE
- No VB runtime detection
- No .NET assembly handling
- Architecture fixed at compile time

### Sécurité
- No validation of PE integrity
- No antivirus scanning
- No code signing verification
- Warning needed before distribution

### Performance
- Large EXE files (>100MB) may be slow
- No parallel package generation
- Sequential section reading

## Futures améliorations

1. Import icon depuis PE .rsrc
2. Détection automatique dépendances
3. Création statique packages (sans rpm build)
4. Signature numérique des paquets
5. Support architectures ARM/ARM64
6. Compression paquets optimisée
7. Mode batch pour multiple files
8. Analyse antivirus (ClamAV)
9. Versionning automatique
10. CI/CD intégration

---

Document technique v1.0 - ExeToTux 2025
